INSERT INTO
    Users (
        username,
        fullname,
        email,
        about_me,
        password,
        picture
    )
VALUES (
        '[deleted]',
        '[deleted]',
        '[deleted]',
        '[deleted]',
        '$2a$10$lLmRUjyC.Yqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- gjorde første X til Y i hashen, men det er en hemmelighet

-- User 1

INSERT INTO
    Users (
        username,
        fullname,
        email,
        about_me,
        password,
        picture
    )
VALUES (
        'john_doe',
        'John Doe',
        'john.doe@example.com',
        'Passionate programmer',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 2

INSERT INTO
    Users (
        username,
        fullname,
        email,
        password,
        picture
    )
VALUES (
        'sarah_smith',
        '',
        'sarah.smith@example.com',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 3

INSERT INTO
    Users (
        username,
        fullname,
        email,
        about_me,
        password,
        picture
    )
VALUES (
        'mike_jones',
        'Mike Jones',
        'mike.jones@example.com',
        '',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 4

INSERT INTO
    Users (
        username,
        email,
        about_me,
        password,
        picture
    )
VALUES (
        'emily_wilson',
        'emily.wilson@example.com',
        'Experienced coder',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 5

INSERT INTO
    Users (
        username,
        fullname,
        email,
        about_me,
        password,
        picture
    )
VALUES (
        'lisa_jackson',
        '',
        'lisa.jackson@example.com',
        '',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 6

INSERT INTO
    Users (
        username,
        email,
        password,
        picture
    )
VALUES (
        'jessica_white',
        'jessica.white@example.com',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 7

INSERT INTO
    Users (
        username,
        fullname,
        email,
        about_me,
        password,
        picture
    )
VALUES (
        'andrew_harris',
        'Andrew Harris',
        'andrew.harris@example.com',
        'Web developer',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 8

INSERT INTO
    Users (
        username,
        email,
        password,
        picture
    )
VALUES (
        'david_brown',
        'david.brown@example.com',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 9

INSERT INTO
    Users (
        username,
        email,
        about_me,
        password,
        picture
    )
VALUES (
        'olivia_davis',
        'olivia.davis@example.com',
        '',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 10

INSERT INTO
    Users (
        username,
        email,
        password,
        picture
    )
VALUES (
        'michael_wilson',
        'michael.wilson@example.com',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 11

INSERT INTO
    Users (
        username,
        fullname,
        email,
        about_me,
        password,
        picture
    )
VALUES (
        'susan_martin',
        '',
        'susan.martin@example.com',
        '',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 12

INSERT INTO
    Users (
        username,
        email,
        password,
        picture
    )
VALUES (
        'daniel_miller',
        'daniel.miller@example.com',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 13

INSERT INTO
    Users (
        username,
        email,
        about_me,
        password,
        picture
    )
VALUES (
        'linda_martinez',
        'linda.martinez@example.com',
        'Backend developer',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 14

INSERT INTO
    Users (
        username,
        email,
        password,
        picture
    )
VALUES (
        'matthew_taylor',
        'matthew.taylor@example.com',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- User 15

INSERT INTO
    Users (
        username,
        email,
        about_me,
        password,
        picture
    )
VALUES (
        'elizabeth_johnson',
        'elizabeth.johnson@example.com',
        'Frontend developer',
        '$2a$10$lLmRUjyC.Xqy3r7jSh6fj.mpYFqDJ7I2fWVJcJ5/JEy.2EVuBLIRS',
        'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg'
    );

-- questions:

-- Question 1

INSERT INTO
    Questions (
        title,
        content,
        timestamp,
        user_id,
        upvotes
    )
VALUES (
        'How to Optimize Database Queries?',
        'I\'m looking for tips and best practices to optimize database queries in my web application.',
        '2023-01-15 14:30:00',
        2,
        9999
    );

-- Question 2

INSERT INTO
    Questions (
        title,
        content,
        timestamp,
        user_id,
        upvotes,
        answered
    )
VALUES (
        'Best Practices for Web Security',
        'What are the best practices for ensuring the security of a web application?',
        '2023-06-20 10:45:00',
        2, (
            SELECT
                RAND() * 10000
        ),
        1
    );

-- Question 3

INSERT INTO
    Questions (
        title,
        content,
        timestamp,
        user_id,
        upvotes
    )
VALUES (
        'Machine Learning Frameworks',
        'I need advice on choosing a machine learning framework for a new project. What are your recommendations?',
        '2023-05-10 16:15:00',
        3, (
            SELECT
                RAND() * 10000
        )

);

-- Question 4

INSERT INTO
    Questions (
        title,
        content,
        timestamp,
        user_id,
        upvotes
    )
VALUES (
        'Frontend Frameworks Comparison',
        'Can someone provide a comparison of popular frontend frameworks like React, Vue, and Angular?',
        '2023-04-25 08:50:00',
        4, (
            SELECT
                RAND() * 10000
        )
    );

-- Question 5

INSERT INTO
    Questions (
        title,
        content,
        timestamp,
        user_id,
        upvotes
    )
VALUES (
        'Cloud Hosting Providers',
        'I\'m interested in cloud hosting solutions. Which cloud hosting provider is the most cost-effective for a small web app?',
        '2023-03-05 17:20:00',
        5, (
            SELECT
                RAND() * 10000
        )
    );

-- Question 6

INSERT INTO
    Questions (
        title,
        content,
        timestamp,
        user_id,
        upvotes
    )
VALUES (
        'JavaScript Frameworks for Single-Page Apps',
        'I\'m planning to build a single - page web application.Which JavaScript framework is best suited for this type of project ? ',
        '2023-02-12 12:40:00 ',
        6, (
            SELECT
                RAND() * 10000
        )
    );

-- Question 7

INSERT INTO
    Questions (
        title,
        content,
        timestamp,
        user_id,
        upvotes
    )
VALUES (
        'Optimizing Website Performance',
        'What techniques can be used to optimize the performance of a website,
        particularly for mobile users?',
        '2023-01-28 14:55:00',
        7, (
            SELECT
                RAND() * 10000
        )
    );

-- Question 8

INSERT INTO
    Questions (
        title,
        content,
        timestamp,
        user_id,
        upvotes
    )
VALUES (
        ' Data Science Tools
        and Libraries ',
        'I\'m exploring data science. What are the essential tools and libraries for data analysis and visualization?',
        '2022-12-09 09:30:00',
        8, (
            SELECT
                RAND() * 10000
        )
    );

-- Question 9

INSERT INTO
    Questions (
        title,
        content,
        timestamp,
        user_id,
        upvotes
    )
VALUES (
        'Database Scaling Strategies',
        'My application\'s database is growing.What are some strategies for scaling the database to handle increased load ? ',
        '2022-11-21 11:20:00 ',
        9, (
            SELECT
                RAND() * 10000
        )
    );

-- Question 10

INSERT INTO
    Questions (
        title,
        content,
        timestamp,
        user_id,
        upvotes
    )
VALUES (
        ' Best Practices for Code Testing ',
        'I\'m interested in adopting code testing practices. What are the best practices for testing code in a development project?',
        '2022-11-07 08:15:00',
        10, (
            SELECT
                RAND() * 10000
        )
    );

-- Tags:

-- Tags for Question 1

INSERT INTO
    Tags (content, question_id)
VALUES ('query-optimization', 1);

INSERT INTO
    Tags (content, question_id)
VALUES ('performance-tuning', 1);

-- Tags for Question 2

INSERT INTO
    Tags (content, question_id)
VALUES ('web-app-security', 2);

INSERT INTO Tags (content, question_id) VALUES ('best-practices', 2);

-- Tags for Question 3

INSERT INTO Tags (content, question_id) VALUES ('python', 3);

-- Tags for Question 4

INSERT INTO Tags (content, question_id) VALUES ('vue', 4);

INSERT INTO Tags (content, question_id) VALUES ('angular', 4);

INSERT INTO
    Tags (content, question_id)
VALUES ('framework-comparison', 4);

-- Tags for Question 5

INSERT INTO Tags (content, question_id) VALUES ('cloud-services', 5);

INSERT INTO
    Tags (content, question_id)
VALUES ('cost-effective-hosting', 5);

-- Tags for Question 6

INSERT INTO
    Tags (content, question_id)
VALUES ('frontend-frameworks', 6);

INSERT INTO
    Tags (content, question_id)
VALUES ('javascript-frameworks', 6);

INSERT INTO
    Tags (content, question_id)
VALUES ('framework-comparison', 6);

-- Tags for Question 7

INSERT INTO
    Tags (content, question_id)
VALUES ('mobile-optimization', 7);

INSERT INTO
    Tags (content, question_id)
VALUES ('web-performance', 7);

-- Tags for Question 8

INSERT INTO Tags (content, question_id) VALUES ('data-analysis', 8);

INSERT INTO
    Tags (content, question_id)
VALUES ('data-visualization', 8);

-- Tags for Question 9

INSERT INTO
    Tags (content, question_id)
VALUES ('scaling-strategies', 9);

-- Tags for Question 10

INSERT INTO Tags (content, question_id) VALUES ('code-testing', 10);

INSERT INTO
    Tags (content, question_id)
VALUES ('test-automation', 10);

-- Favorites:

-- User 1 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (1, 'database');

INSERT INTO
    Favorites (user_id, tag)
VALUES (1, 'query-optimization');

-- User 2 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (2, 'web-security');

-- User 3 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (3, 'machine-learning');

INSERT INTO Favorites (user_id, tag) VALUES (3, 'python');

-- User 4 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (4, 'frontend');

INSERT INTO Favorites (user_id, tag) VALUES (4, 'vue');

-- User 5 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (5, 'cloud-hosting');

-- User 6 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (6, 'javascript');

INSERT INTO Favorites (user_id, tag) VALUES (6, 'spa');

-- User 7 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (7, 'performance');

INSERT INTO
    Favorites (user_id, tag)
VALUES (7, 'mobile-optimization');

-- User 8 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (8, 'data-science');

-- User 9 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (9, 'database-scaling');

-- User 10 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (10, 'code-testing');

-- User 11 Favorites

INSERT INTO
    Favorites (user_id, tag)
VALUES (11, 'software-development');

-- User 12 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (12, 'web-development');

INSERT INTO Favorites (user_id, tag) VALUES (12, 'frontend');

-- User 13 Favorites

INSERT INTO
    Favorites (user_id, tag)
VALUES (13, 'backend-development');

INSERT INTO Favorites (user_id, tag) VALUES (13, 'javascript');

-- User 14 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (14, 'data-analysis');

-- User 15 Favorites

INSERT INTO Favorites (user_id, tag) VALUES (15, 'coding');

INSERT INTO Favorites (user_id, tag) VALUES (15, 'software');

-- questions:

-- Answers for Question 1

INSERT INTO
    Answers (
        content,
        timestamp,
        user_id,
        upvotes,
        question_id
    )
VALUES (
        'You can optimize database queries by creating indexes on frequently queried columns.',
        '2023-07-20 15:10:00',
        2, (
            SELECT
                RAND() * 100
        ),
        1
    );

INSERT INTO
    Answers (
        content,
        timestamp,
        user_id,
        upvotes,
        question_id
    )
VALUES (
        'Consider using a caching layer to reduce the load on the database.',
        '2023-07-21 09:45:00',
        3, (
            SELECT
                RAND() * 100
        ),
        1
    );

INSERT INTO
    Answers (
        content,
        timestamp,
        user_id,
        upvotes,
        question_id
    )
VALUES (
        'Using stored procedures and optimizing your SQL queries is crucial for database performance.',
        '2023-07-22 11:30:00',
        4, (
            SELECT
                RAND() * 100
        ),
        1
    );

-- Answers for Question 2

INSERT INTO
    Answers (
        content,
        timestamp,
        user_id,
        upvotes,
        question_id,
        best_answer
    )
VALUES (
        'Use HTTPS to secure data transmission and implement input validation for user inputs.',
        '2023-06-25 13:20:00',
        5, (
            SELECT
                RAND() * 100
        ),
        2,
        1
    );

-- Answers for Question 3

INSERT INTO
    Answers (
        content,
        timestamp,
        user_id,
        upvotes,
        question_id
    )
VALUES (
        'Python offers a wide range of libraries for machine learning, including TensorFlow and scikit-learn.',
        '2023-05-15 18:05:00',
        1, (
            SELECT
                RAND() * 100
        ),
        3
    );

INSERT INTO
    Answers (
        content,
        timestamp,
        user_id,
        upvotes,
        question_id
    )
VALUES (
        'Consider your project requirements and data types when choosing a machine learning framework.',
        '2023-05-16 10:55:00',
        2, (
            SELECT
                RAND() * 100
        ),
        3
    );

-- Answers for Question 4

INSERT INTO
    Answers (
        content,
        timestamp,
        user_id,
        upvotes,
        question_id
    )
VALUES (
        'React is great for building dynamic web apps with a component-based structure.',
        '2023-04-27 14:50:00',
        3, (
            SELECT
                RAND() * 100
        ),
        4
    );

-- Answers for Question 5

INSERT INTO
    Answers (
        content,
        timestamp,
        user_id,
        upvotes,
        question_id
    )
VALUES (
        'Popular cloud hosting providers include AWS, Azure, and Google Cloud. Evaluate your project needs to choose the best one.',
        '2023-03-10 16:30:00',
        4, (
            SELECT
                RAND() * 100
        ),
        5
    );

INSERT INTO
    Answers (
        content,
        timestamp,
        user_id,
        upvotes,
        question_id
    )
VALUES (
        'Consider serverless computing to reduce costs on cloud hosting.',
        '2023-03-12 09:40:00',
        5, (
            SELECT
                RAND() * 100
        ),
        5
    );

-- A_comments:

-- Comments for Answer 1 to Question 1

INSERT INTO
    A_comments (
        content,
        timestamp,
        user_id,
        answer_id
    )
VALUES (
        'Great advice on query optimization!',
        '2023-07-22 16:30:00',
        2,
        1
    );

INSERT INTO
    A_comments (
        content,
        timestamp,
        user_id,
        answer_id
    )
VALUES (
        'I implemented these strategies, and our database is much faster now.',
        '2023-07-23 09:15:00',
        3,
        1
    );

-- Comments for Answer 2 to Question 1

INSERT INTO
    A_comments (
        content,
        timestamp,
        user_id,
        answer_id
    )
VALUES (
        'Caching made a significant difference for our website.',
        '2023-07-24 14:40:00',
        4,
        2
    );

-- Comment for Answer 1 to Question 2

INSERT INTO
    A_comments (
        content,
        timestamp,
        user_id,
        answer_id
    )
VALUES (
        'Your insights on web security are valuable. Thanks for sharing!',
        '2023-06-26 12:30:00',
        5,
        1
    );

-- Comment for Answer 1 to Question 3

INSERT INTO
    A_comments (
        content,
        timestamp,
        user_id,
        answer_id
    )
VALUES (
        'I agree with your recommendations for machine learning libraries.',
        '2023-05-17 09:45:00',
        6,
        1
    );

-- Comment for Answer 2 to Question 3

INSERT INTO
    A_comments (
        content,
        timestamp,
        user_id,
        answer_id
    )
VALUES (
        'Choosing the right machine learning framework is a crucial decision.',
        '2023-05-17 10:50:00',
        7,
        2
    );

-- Comment for Answer 1 to Question 4

INSERT INTO
    A_comments (
        content,
        timestamp,
        user_id,
        answer_id
    )
VALUES (
        'React is my favorite frontend framework. It\'s so versatile!',
        '2023-04-29 13:15:00',
        8,
        1
    );

-- Comment for Answer 1 to Question 5

INSERT INTO
    A_comments (
        content,
        timestamp,
        user_id,
        answer_id
    )
VALUES (
        'Your cloud hosting advice was a game-changer for our project.',
        '2023-03-14 14:30:00',
        9,
        1
    );

-- Comment for Answer 2 to Question 5

INSERT INTO
    A_comments (
        content,
        timestamp,
        user_id,
        answer_id
    )
VALUES (
        'Serverless computing has transformed our cloud infrastructure.',
        '2023-03-15 11:20:00',
        10,
        2
    );

-- Q_comments:

-- Comments for Question 1

INSERT INTO
    Q_comments (
        content,
        timestamp,
        user_id,
        question_id
    )
VALUES (
        'Great question! I\'m also interested in optimizing database performance.',
        '2023-07-20 16:45:00',
        7,
        1
    );

INSERT INTO
    Q_comments (
        content,
        timestamp,
        user_id,
        question_id
    )
VALUES (
        'This is a common challenge in database management. Let\'s discuss solutions.',
        '2023-07-22 11:30:00',
        8,
        1
    );

-- Comments for Question 2

INSERT INTO
    Q_comments (
        content,
        timestamp,
        user_id,
        question_id
    )
VALUES (
        'I\'ve been researching web security. Your question is quite relevant.',
        '2023-06-24 14:10:00',
        10,
        2
    );

-- Comment for Question 3

INSERT INTO
    Q_comments (
        content,
        timestamp,
        user_id,
        question_id
    )
VALUES (
        'I\'m also exploring machine learning. Let\'s share insights!',
        '2023-05-15 20:15:00',
        11,
        3
    );

-- Comment for Question 4

INSERT INTO
    Q_comments (
        content,
        timestamp,
        user_id,
        question_id
    )
VALUES (
        'Frontend development is fascinating. Can\'t wait to see answers to this question.',
        '2023-04-25 13:20:00',
        12,
        4
    );

-- Comment for Question 5

INSERT INTO
    Q_comments (
        content,
        timestamp,
        user_id,
        question_id
    )
VALUES (
        'I\'m looking for insights on cloud hosting. Your question caught my attention.',
        '2023-03-09 11:50:00',
        13,
        5
    );

-- User_saved:

-- User 1 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (1, 1);

-- User 2 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (2, 4);

INSERT INTO User_saved (user_id, question_id) VALUES (2, 6);

-- User 3 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (3, 5);

-- User 4 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (4, 2);

-- User 5 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (5, 3);

-- User 6 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (6, 7);

-- User 7 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (7, 10);

-- User 8 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (8, 9);

-- User 9 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (9, 8);

-- User 10 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (10, 1);

INSERT INTO User_saved (user_id, question_id) VALUES (10, 6);

-- User 11 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (11, 3);

-- User 12 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (12, 2);

INSERT INTO User_saved (user_id, question_id) VALUES (12, 4);

-- User 13 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (13, 5);

-- User 14 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (14, 7);

-- User 15 Saved Questions

INSERT INTO User_saved (user_id, question_id) VALUES (15, 8);