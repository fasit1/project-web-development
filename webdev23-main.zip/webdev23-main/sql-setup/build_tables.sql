DROP TABLE IF EXISTS Q_comments;

DROP TABLE IF EXISTS A_comments;

DROP TABLE IF EXISTS Q_points;

DROP TABLE IF EXISTS A_points;

DROP TABLE IF EXISTS Tags;

DROP TABLE IF EXISTS Answers;

DROP TABLE IF EXISTS User_saved;

DROP TABLE IF EXISTS Questions;

DROP TABLE IF EXISTS Favorites;

DROP TABLE IF EXISTS Users;

CREATE TABLE
    Users (
        user_id INT AUTO_INCREMENT,
        google_id TINYTEXT,
        username TINYTEXT NOT NULL,
        fullname TINYTEXT,
        email TINYTEXT NOT NULL,
        picture TEXT,
        about_me TEXT,
        password TINYTEXT NOT NULL,
        CONSTRAINT users_pk PRIMARY KEY(user_id)
    );

CREATE TABLE
    Favorites (
        user_id INT,
        tag VARCHAR(32),
        CONSTRAINT favorites_pk PRIMARY KEY(user_id, tag),
        CONSTRAINT f_users_fk FOREIGN KEY (user_id) REFERENCES Users(user_id)
    );

CREATE TABLE
    Questions (
        question_id INT AUTO_INCREMENT,
        title TINYTEXT NOT NULL,
        content MEDIUMTEXT NOT NULL,
        timestamp DATETIME NOT NULL,
        answered BOOLEAN DEFAULT 0,
        user_id INT NOT NULL,
        upvotes INT DEFAULT 0,
        CONSTRAINT questions_pk PRIMARY KEY(question_id),
        CONSTRAINT q_users_fk FOREIGN KEY(user_id) REFERENCES Users(user_id)
    );

CREATE TABLE
    Q_comments (
        comment_id INT AUTO_INCREMENT,
        content MEDIUMTEXT NOT NULL,
        timestamp DATETIME NOT NULL,
        user_id INT NOT NULL,
        question_id INT NOT NULL,
        CONSTRAINT qc_comments_pk PRIMARY KEY(comment_id),
        CONSTRAINT qc_users_fk FOREIGN KEY(user_id) REFERENCES Users(user_id),
        CONSTRAINT qc_questions_fk FOREIGN KEY(question_id) REFERENCES Questions(question_id)
    );

CREATE TABLE
    Answers (
        answer_id INT AUTO_INCREMENT,
        content MEDIUMTEXT NOT NULL,
        timestamp DATETIME NOT NULL,
        best_answer BOOLEAN DEFAULT 0,
        user_id INT NOT NULL,
        question_id INT,
        upvotes INT DEFAULT 0,
        CONSTRAINT answers_pk PRIMARY KEY(answer_id),
        CONSTRAINT a_users_fk FOREIGN KEY(user_id) REFERENCES Users(user_id),
        CONSTRAINT a_questions_fk FOREIGN KEY(question_id) REFERENCES Questions(question_id)
    );

CREATE TABLE
    A_comments (
        comment_id INT AUTO_INCREMENT,
        content MEDIUMTEXT NOT NULL,
        timestamp DATETIME NOT NULL,
        user_id INT NOT NULL,
        answer_id INT NOT NULL,
        CONSTRAINT ac_comments_pk PRIMARY KEY(comment_id),
        CONSTRAINT ac_users_fk FOREIGN KEY(user_id) REFERENCES Users(user_id),
        CONSTRAINT ac_answers_fk FOREIGN KEY(answer_id) REFERENCES Answers(answer_id)
    );

CREATE TABLE
    Tags (
        content TINYTEXT NOT NULL,
        question_id INT NOT NULL,
        CONSTRAINT t_questions_fk FOREIGN KEY (question_id) REFERENCES Questions(question_id)
    );

CREATE TABLE
    User_saved (
        user_id INT NOT NULL,
        question_id INT NOT NULL,
        CONSTRAINT us_users_fk FOREIGN KEY(user_id) REFERENCES Users(user_id),
        CONSTRAINT us_questions_fk FOREIGN KEY(question_id) REFERENCES Questions(question_id)
    );

CREATE TABLE
    Q_points (
        user_id INT NOT NULL,
        question_id INT NOT NULL,
        upvote BOOLEAN,
        CONSTRAINT qp_points_pk PRIMARY KEY(user_id, question_id),
        CONSTRAINT qp_users_fk FOREIGN KEY(user_id) REFERENCES Users(user_id),
        CONSTRAINT qp_questions_fk FOREIGN KEY(question_id) REFERENCES Questions(question_id)
    );

CREATE TABLE
    A_points (
        user_id INT NOT NULL,
        answer_id INT NOT NULL,
        upvote BOOLEAN,
        CONSTRAINT ap_points_pk PRIMARY KEY(user_id, answer_id),
        CONSTRAINT ap_users_fk FOREIGN KEY(user_id) REFERENCES Users(user_id),
        CONSTRAINT ap_questions_fk FOREIGN KEY(answer_id) REFERENCES Answers(answer_id)
    );