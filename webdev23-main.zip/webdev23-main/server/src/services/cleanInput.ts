function cleanInput(input: string): string {
  // escapes characters as a safeguard for SQL
  const cleanedInput = input.replace(/'/g, "\\'").replace(/"/g, '\\"').replace(/;/g, '\\;');
  return cleanedInput;
}

export default cleanInput;
