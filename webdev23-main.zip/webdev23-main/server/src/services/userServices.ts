import pool from '../mysql-pool';
import type { RowDataPacket, ResultSetHeader } from 'mysql2';
import bcrypt from 'bcryptjs';
import { User, UserWithPassword } from '../../../client/src/components/customTypes';

const url = 'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg';
// we use this to set a profile picture if the user deletes their picture

class UserServices {
  getUserByUsername(username: string) {
    return new Promise<UserWithPassword>((resolve, reject) => {
      pool.query(
        'SELECT * FROM Users WHERE username = ?',
        [username],
        (error, results: RowDataPacket[]) => {
          if (error) return reject(error);
          resolve(results[0] as UserWithPassword);
        },
      );
    });
  }
  getUserByEmail(email: string) {
    return new Promise<UserWithPassword>((resolve, reject) => {
      pool.query(
        'SELECT * FROM Users WHERE email = ?',
        [email],
        (error, results: RowDataPacket[]) => {
          if (error) return reject(error);
          resolve(results[0] as UserWithPassword);
        },
      );
    });
  }
  getUserById(user_id: number) {
    return new Promise<User>((resolve, reject) => {
      pool.query(
        'SELECT * FROM Users WHERE user_id = ?',
        [user_id],
        (error, results: RowDataPacket[]) => {
          if (error) return reject(error);
          resolve(results[0] as User);
        },
      );
    });
  }

  getContentByUserId(user_id: number) {
    return new Promise((resolve, reject) => {
      const query = `
      SET @user_id = ?;
      SELECT q.*, COUNT(a.answer_id) AS answer_count FROM Questions AS q
      LEFT JOIN Answers AS a ON q.question_id = a.question_id WHERE q.user_id=@user_id
      GROUP BY q.question_id;
      SELECT a.*, q.title FROM Answers AS a JOIN Questions AS q ON a.question_id = q.question_id WHERE a.user_id=@user_id;
      SELECT qc.*, q.title FROM Q_comments AS qc JOIN Questions AS q ON qc.question_id = q.question_id WHERE qc.user_id=@user_id;
      SELECT ac.*, a.question_id, q.title FROM A_comments AS ac JOIN Answers AS a ON ac.answer_id = a.answer_id JOIN Questions AS q ON a.question_id = q.question_id WHERE ac.user_id=@user_id;

      SELECT (
        SELECT count(user_id)
        FROM Questions
        WHERE user_id = @user_id
      ) as questions, (
        SELECT count(user_id)
        FROM Answers
        WHERE user_id = @user_id
      ) as answers, (
        SELECT count(user_id)
        FROM Q_comments
        WHERE user_id = @user_id
        ) + (
        SELECT count(user_id)
        FROM A_comments
        WHERE user_id = @user_id
      ) as comments;
      SELECT
      IFNULL(sum(upvotes), 0) + (
          SELECT
              IFNULL(sum(upvotes), 0)
          FROM Answers
          WHERE
              user_id = @user_id
      ) AS points
    FROM Questions WHERE user_id = @user_id;
      SELECT username, fullname, picture, about_me FROM Users WHERE user_id=@user_id;
      `;
      pool.query(query, [user_id], (error, results: RowDataPacket[]) => {
        if (error) return reject(error);
        results.splice(0, 1);
        var result = {
          questions: results[0],
          answers: results[1],
          q_comments: results[2],
          a_comments: results[3],
          stats: results[4][0],
        };
        result.stats.points = Number(results[5][0].points);
        resolve(result);
      });
    });
  }

  private async hashPassword(password: string): Promise<string> {
    return await bcrypt.hash(password, 10); //number of rounds to use when hashing the password
  }

  //attempt to create a unique username
  private async attemptUsernameCreation(
    baseUsername: string,
    google_id: string,
    displayName: string,
    email: { value: string },
    picture: string,
    about_me: string,
    done: (err: any, user?: User) => void,
  ) {
    const randomNumber = Math.floor(Math.random() * 100) + 1;
    const username = `${baseUsername}${randomNumber}`;
    const picture_url = picture;
    pool.query(
      'SELECT * FROM Users WHERE google_id = ?',
      [google_id],
      async (error, results: RowDataPacket[]) => {
        if (error) return done(new Error('userServices hent fra google_id'));
        if (results.length === 0) {
          //username is unique
          const hashedPassword = await this.hashPassword('Passord123');

          pool.query(
            'INSERT INTO Users (google_id, fullname, email, username, password, picture, about_me) VALUES (?,?,?,?,?,?,?)',
            [google_id, displayName, email.value, username, hashedPassword, picture_url, about_me],
            (error, _results: ResultSetHeader) => {
              if (error) return done(new Error('userServices insert'));
              pool.query(
                'SELECT * FROM Users WHERE google_id = ?',
                [google_id],
                (error, results: RowDataPacket[]) => {
                  if (error) return done(new Error('userServices select fra google_id'));
                  return done(null, results[0] as User);
                },
              );
            },
          );
        }
      },
    );
  }
  //find or create a user
  findOrCreate(
    google_id: string,
    displayName: string,
    email: { value: string },
    picture: string,
    about_me: string,
    done: (err: any, user?: User) => void,
  ) {
    pool.query(
      'SELECT * FROM Users WHERE google_id = ?',
      [google_id],
      (error, results: RowDataPacket[]) => {
        if (error) return done(new Error('userServices database'));
        if (results.length > 0) {
          return done(null, results[0] as User);
        } else {
          if (!displayName) {
            return done(new Error('displayName is undefined'));
          }
        }
        //create a unique username
        const baseUsername = displayName.replace(/\s/g, '');
        this.attemptUsernameCreation(
          baseUsername,
          google_id,
          displayName,
          email,
          picture,
          about_me,
          done,
        );
        if (error) return done(new Error('userServices prøve å lage unikt brukernavn'));
      },
    );
  }

  createUser(
    username: string,
    password: string,
    email: string,
    firstName: string,
    lastName: string,
  ) {
    username = username.replace(/[^a-zA-Z0-9-_]/g, '').replace(/\u200B/g, '');
    email = email.replace(/[^a-zA-Z0-9!#$%&*+\-_~@.]+/g, '').replace(/\u200B/g, '');
    const picture = url;
    return new Promise<number>((resolve, reject) => {
      pool.query(
        'INSERT INTO Users (username, password, email, fullname, picture) VALUES (?,?,?,?, ?)',
        [username, password, email, `${firstName} ${lastName}`, picture],
        (error, results: ResultSetHeader) => {
          if (error) return reject(error);
          resolve(results.insertId);
        },
      );
    });
  }

  deleteUser(user_id: number) {
    // this moves ownership of content from the user over to an inactive user, then deletes dependencies, and finally the user
    return new Promise<User>((resolve, reject) => {
      const query = `
      SET @user_id = ?;
      UPDATE Q_comments SET user_id = 1 WHERE user_id=@user_id;
      UPDATE A_comments SET user_id = 1 WHERE user_id=@user_id;
      DELETE FROM Q_points WHERE user_id=@user_id;
      DELETE FROM A_points WHERE user_id=@user_id;
      UPDATE Answers SET user_id = 1 WHERE user_id=@user_id;
      DELETE FROM User_saved WHERE user_id=@user_id;
      UPDATE Questions SET user_id = 1 WHERE user_id=@user_id;
      DELETE FROM Favorites WHERE user_id=@user_id;
      DELETE FROM Users WHERE user_id=@user_id;`;
      pool.query(query, [user_id], (error, results: RowDataPacket[]) => {
        if (error) return reject(error);
        resolve(results[0] as User);
      });
    });
  }

  getAllUsernames() {
    return new Promise<{ username: string }[]>((resolve, reject) => {
      pool.query('SELECT username FROM Users;', (error, results: RowDataPacket[]) => {
        if (error) return reject(error);
        results.splice(0, 1);
        // Removes [deleted] user
        resolve(results as { username: string }[]);
      });
    });
  }

  updateUser(user: User) {
    return new Promise<any>((resolve, reject) => {
      user.username = user.username.replace(/[^a-zA-Z0-9-_]/g, '').replace(/\u200B/g, '');
      user.email = user.email.replace(/[^a-zA-Z0-9!#$%&*+\-_~@.]+/g, '').replace(/\u200B/g, '');
      // this clears illegal inputs
      pool.query(
        'UPDATE Users SET username = ?, email = ?, fullname = ?, picture = ?, about_me = ? WHERE user_id = ?;',
        [user.username, user.email, user.fullname, user.picture, user.about_me, user.user_id],
        (error, results: RowDataPacket[]) => {
          if (error) {
            return reject(error);
          }
          resolve(results);
        },
      );
    });
  }
}

export const userServices = new UserServices();
