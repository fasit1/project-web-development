import pool from '../mysql-pool';
import type { RowDataPacket } from 'mysql2';

import { Tag } from '../../../client/src/components/customTypes';

class TagServices {
  getFavorites(user_id: number) {
    return new Promise<Tag[]>((resolve, reject) => {
      pool.query(
        'SELECT tag as content FROM Favorites WHERE user_id = ?;',
        [user_id],
        (error, results: RowDataPacket[]) => {
          if (error) return reject(error);
          resolve(results as Tag[]);
        },
      );
    });
  }

  getPopular() {
    return new Promise<Tag[]>((resolve, reject) => {
      pool.query(
        `
        SELECT
            content,
            COUNT(content) AS question_amount
        FROM Tags
        GROUP BY content
        ORDER BY question_amount DESC
        LIMIT 15;
        `,
        (error, results: RowDataPacket[]) => {
          if (error) return reject(error);
          resolve(results as Tag[]);
        },
      );
    });
  }

  getAll() {
    return new Promise<Tag[]>((resolve, reject) => {
      pool.query(
        'SELECT DISTINCT content, count(content) as question_amount FROM Tags GROUP BY content;',
        (error, results: RowDataPacket[]) => {
          if (error) return reject(error);
          resolve(results as Tag[]);
        },
      );
    });
  }

  addToFavorites(user_id: number, tag: Tag) {
    return new Promise((resolve, reject) => {
      pool.query(
        'INSERT INTO Favorites (user_id, tag) VALUES (?, ?);',
        [user_id, tag.content],
        (error, results: RowDataPacket[]) => {
          if (error) return reject(error);
          resolve(results);
        },
      );
    });
  }

  removeFromFavorites(user_id: number, tag: string) {
    return new Promise((resolve, reject) => {
      pool.query(
        'DELETE FROM Favorites WHERE user_id = ? AND tag = ?;',
        [user_id, tag],
        (error, results: RowDataPacket[]) => {
          if (error) return reject(error);
          resolve(results);
        },
      );
    });
  }
}

const tagServices = new TagServices();
export default tagServices;
