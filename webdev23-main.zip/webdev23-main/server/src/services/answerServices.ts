import pool from '../mysql-pool';
import type { ResultSetHeader } from 'mysql2';
import cleanInput from './cleanInput';

import { Answer, A_comment } from '../../../client/src/components/customTypes';

class AnswerServices {
  create(question_id: number, user_id: number, content: string) {
    return new Promise<any>((resolve, reject) => {
      var query = `
        INSERT INTO Answers(
            question_id,
            user_id,
            content,
            timestamp)
        VALUES(
            ?,?,?,?);`;
      pool.query(
        query,
        [question_id, user_id, cleanInput(content), new Date()],
        (error, results: ResultSetHeader) => {
          if (error) return reject(error);
          resolve(results);
        },
      );
    });
  }

  delete(user_id: number, answer_id: number) {
    //this method does not delete the row in the table, but wipes the content
    //this is because of dependencies
    return new Promise<any>((resolve, reject) => {
      pool.query(
        `SET @user_id = ?;
        SET @answer_id = ?;
        SET @owner = (SELECT user_id FROM Answers WHERE answer_id = @answer_id);
        SELECT IF(
          @user_id = @owner,
          @delete_query := "UPDATE Answers SET content='[deleted]', user_id=1 WHERE answer_id = @answer_id;",
          @delete_query := "RETURN 1;"
        );
        PREPARE delete_answer FROM @delete_query;
        EXECUTE delete_answer;
        DEALLOCATE PREPARE delete_answer;`,
        [user_id, answer_id],
        (error, results: ResultSetHeader) => {
          if (error) return reject(error);
          resolve(results);
        },
      );
    });
  }

  update(user_id: number, answer: Answer) {
    return new Promise<any>((resolve, reject) => {
      pool.query(
        `SET @user_id = ?;
        SET @answer_id = ?;
        SET @owner = (SELECT user_id FROM Answers WHERE answer_id = @answer_id);
        SELECT IF(
          @user_id = @owner,
          @edit_query := "UPDATE Answers SET content=?, best_answer=? WHERE answer_id = @answer_id",
          @edit_query := "RETURN 1;"
        );
        PREPARE edit_answer FROM @edit_query;
        EXECUTE edit_answer;
        DEALLOCATE PREPARE edit_answer;`,
        [user_id, answer.answer_id, cleanInput(answer.content), answer.best_answer],
        (error, results) => {
          if (error) return reject(error);

          resolve(results);
        },
      );
    });
  }

  upvote(answer_id: number, user_id: number) {
    return new Promise<any>((resolve, reject) => {
      const query = `
      SET @answer_id=?;

      SET @user_id = ?;

      SET @current_vote = (
        SELECT upvote
        FROM A_points
        WHERE
            answer_id = @answer_id
            AND user_id = @user_id
      );

      SET @prior_vote = (SELECT IF(@current_vote < 2, 1,0));

      SELECT
        IF(
          @prior_vote = 1,
          IF(
            @current_vote = 1,
            @vote_query := 'UPDATE Answers SET upvotes = upvotes - 1 WHERE answer_id = @answer_id',
            @vote_query := 'UPDATE Answers SET upvotes = upvotes + 2 WHERE answer_id = @answer_id'
          ),
          @vote_query := 'UPDATE Answers SET upvotes = upvotes + 1 WHERE answer_id = @answer_id'
        );

      PREPARE update_points FROM @vote_query;

      EXECUTE update_points;

      DEALLOCATE PREPARE update_points;

      SELECT
        IF(
          @prior_vote = 1,
          IF(
            @current_vote = 1,
            @vote_query := 'DELETE FROM A_points WHERE user_id = @user_id AND answer_id = @answer_id',
            @vote_query := 'UPDATE A_points SET upvote = 1 WHERE user_id = @user_id AND answer_id = @answer_id'
          ),
          @vote_query := 'INSERT INTO A_points (user_id, answer_id, upvote) VALUES (@user_id, @answer_id, 1)'
        );

      PREPARE register_vote FROM @vote_query;

      EXECUTE register_vote;

      DEALLOCATE PREPARE register_vote;
      `;
      pool.query(query, [answer_id, user_id], (error, results) => {
        if (error) return reject(error);
        resolve(results);
      });
    });
  }

  downvote(answer_id: number, user_id: number) {
    return new Promise<any>((resolve, reject) => {
      const query = `
      SET @answer_id=?;

      SET @user_id = ?;

      SET @current_vote = (
        SELECT upvote
        FROM A_points
        WHERE
            answer_id = @answer_id
            AND user_id = @user_id
      );

      SET @prior_vote = (SELECT IF(@current_vote < 2, 1,0));

      SELECT
        IF(
          @prior_vote = 1,
          IF(
            @current_vote = 1,
            @vote_query := 'UPDATE Answers SET upvotes = upvotes - 2 WHERE answer_id = @answer_id',
            @vote_query := 'UPDATE Answers SET upvotes = upvotes + 1 WHERE answer_id = @answer_id'
          ),
          @vote_query := 'UPDATE Answers SET upvotes = upvotes - 1 WHERE answer_id = @answer_id'
        );

      PREPARE update_points FROM @vote_query;

      EXECUTE update_points;

      DEALLOCATE PREPARE update_points;

      SELECT
        IF(
          @prior_vote = 1,
          IF(
            @current_vote = 1,
            @vote_query := 'UPDATE A_points SET upvote = 0 WHERE user_id = @user_id AND answer_id = @answer_id',
            @vote_query := 'DELETE FROM A_points WHERE user_id = @user_id AND answer_id = @answer_id'
          ),
          @vote_query := 'INSERT INTO A_points (user_id, answer_id, upvote) VALUES (@user_id, @answer_id, 0)'
        );

      PREPARE register_vote FROM @vote_query;

      EXECUTE register_vote;

      DEALLOCATE PREPARE register_vote;
      `;
      pool.query(query, [answer_id, user_id], (error, results) => {
        if (error) return reject(error);
        resolve(results);
      });
    });
  }
  newComment(answer_id: number, user_id: number, content: string) {
    return new Promise<any>((resolve, reject) => {
      var query = `INSERT INTO A_comments (answer_id, user_id, content, timestamp) VALUES (?,?,?,?);`;
      pool.query(
        query,
        [answer_id, user_id, cleanInput(content), new Date()],
        (error, results: ResultSetHeader) => {
          if (error) return reject(error);
          resolve(results);
        },
      );
    });
  }
  editComment(user_id: number, comment: A_comment) {
    const query = `SET @user_id = ?;
        SET @comment_id = ?;
        SET @owner = (SELECT user_id FROM A_comments WHERE comment_id = @comment_id);
        SELECT IF(
          @user_id = @owner,
          @edit_query := "UPDATE A_comments SET content=? WHERE comment_id = @comment_id;",
          @edit_query := "RETURN 1;"
        );
        PREPARE edit_comment FROM @edit_query;
        EXECUTE edit_comment;
        DEALLOCATE PREPARE edit_comment;`;
    return new Promise<any>((resolve, reject) => {
      pool.query(
        query,
        [user_id, comment.comment_id, cleanInput(comment.content)],
        (error, results) => {
          if (error) return reject(error);

          resolve(results);
        },
      );
    });
  }

  deleteComment(user_id: number, comment_id: number) {
    const query = `SET @user_id = ?;
        SET @comment_id = ?;
        SET @owner = (SELECT user_id FROM A_comments WHERE comment_id = @comment_id);
        SELECT IF(
          @user_id = @owner,
          @edit_query := "DELETE FROM A_comments WHERE comment_id = @comment_id;",
          @edit_query := "RETURN 1;"
        );
        PREPARE edit_comment FROM @edit_query;
        EXECUTE edit_comment;
        DEALLOCATE PREPARE edit_comment;`;
    return new Promise<any>((resolve, reject) => {
      pool.query(query, [user_id, comment_id], (error, results) => {
        if (error) return reject(error);

        resolve(results);
      });
    });
  }
}

const answerServices = new AnswerServices();
export default answerServices;
