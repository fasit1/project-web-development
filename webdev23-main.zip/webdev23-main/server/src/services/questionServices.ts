import pool from '../mysql-pool';
import type { RowDataPacket, ResultSetHeader } from 'mysql2';
import cleanInput from './cleanInput';

import {
  Question,
  Tag,
  Q_comment,
  Answer,
  A_comment,
} from '../../../client/src/components/customTypes';

// This sets the amount of days which getAllQuestions() defines as "recent"
const interval = 365;
// This decides the amount of questions that getAllQuestions() retrives
const limit = 10;

class QuestionServices {
  /**
   * Get question with given id.
   */
  getQuestion(question_id: number, user_id: number) {
    const query = `
    SET @question_id=?;
    SET @user_id=?;

    SELECT q.*, u.username, u.fullname, IFNULL(p.upvote, 2) AS voted_by_user
    FROM Questions AS q
    JOIN Users AS u ON q.user_id = u.user_id
    LEFT OUTER JOIN (
        SELECT *
        FROM Q_points
        WHERE user_id = @user_id
    ) AS p ON q.question_id = p.question_id
    WHERE q.question_id = @question_id;

    SELECT content FROM Tags WHERE question_id = @question_id;

    SELECT a.*, u.username, u.fullname, IFNULL(p.upvote, 2) AS voted_by_user
    FROM Answers AS a
    JOIN Users AS u ON a.user_id = u.user_id
    LEFT OUTER JOIN (
        SELECT *
        FROM A_points
        WHERE user_id = @user_id
    ) AS p ON a.answer_id = p.answer_id
    WHERE a.question_id = @question_id ORDER BY a.best_answer DESC;

    SELECT
      c.*,
      u.username,
      u.fullname
    FROM Q_comments AS c
    JOIN Users as u on c.user_id = u.user_id
    WHERE question_id = @question_id;

    SELECT c.*, u.username, u.fullname FROM
      (SELECT ac.*
      FROM A_comments AS ac
      JOIN Answers AS a ON ac.answer_id = a.answer_id
      WHERE a.question_id = @question_id) AS c
    JOIN Users AS u on c.user_id = u.user_id;
    `;
    return new Promise<Question | undefined>((resolve, reject) => {
      pool.query(query, [question_id, user_id], (error, results: RowDataPacket[]) => {
        if (error) return reject(error);
        if (results[2].length == 0) return reject('Question not found');
        const result = {
          question: results[2][0] as Question,
        };
        result.question.comments = results[5] as Q_comment[];
        result.question.tags = results[3] as Tag[];
        result.question.answers = results[4] as Answer[];
        result.question.answers.forEach((answer: Answer) => {
          answer.comments = [];
          results[6].map((comment: A_comment) => {
            if (comment.answer_id == answer.answer_id) {
              answer.comments.push(comment);
            }
          });
        });
        resolve(result.question);
      });
    });
  }

  /**
   * Get all questions.
   */

  getEveryQuestion() {
    return new Promise<Question[]>((resolve, reject) => {
      pool.query('SELECT * FROM Questions', (error, results) => {
        if (error) return reject(error);
        resolve(results as Question[]);
      });
    });
  }

  getAllQuestions(sorting: string, answered: string, user_id: number) {
    var query = `
    SELECT q.*, u.username, u.fullname, IFNULL(p.upvote, 2) as voted_by_user
    FROM Questions AS q 
    JOIN Users AS u ON q.user_id = u.user_id
    LEFT OUTER JOIN (
      SELECT * FROM Q_points 
      WHERE user_id = ?) AS p 
    ON q.question_id = p.question_id`;
    if (answered == 'answered') {
      query += ' WHERE q.answered = 1';
    } else if (answered == 'unanswered') {
      query += ' WHERE q.answered = 0';
    }
    if (sorting == 'recent') {
      query += ' ORDER BY q.timestamp DESC';
    } else if (sorting == 'popular') {
      if (query.includes('WHERE')) {
        query += ' AND';
      } else {
        query += ' WHERE';
      }
      query += ` q.timestamp >= DATE_SUB(CURDATE(), INTERVAL ${interval} DAY)`;
      query += ' ORDER BY q.upvotes DESC';
    } else if (sorting == 'topAllTime') {
      query += ' ORDER BY q.upvotes DESC';
    }
    query += ` LIMIT ${limit};`;
    query += 'SELECT * FROM Tags;';
    return new Promise<Question[]>((resolve, reject) => {
      pool.query(query, [user_id], (error, results: RowDataPacket[]) => {
        if (error) return reject(error);
        results[0].map((question: Question) => {
          question.tags = [];
          results[1].map((tag: any) =>
            question.question_id == tag.question_id ? question.tags?.push(tag.content) : '',
          );
        });
        resolve(results[0] as Question[]);
      });
    });
  }

  getQuestionsByTag(tag: string, sorting: string, answered: string, user_id: number) {
    return new Promise<Question[]>((resolve, reject) => {
      var query = `
      SELECT q.*, u.username, u.fullname, IFNULL(p.upvote, 2) AS voted_by_user
      FROM Questions AS q
      JOIN Users AS u ON q.user_id = u.user_id
      JOIN Tags AS t ON q.question_id = t.question_id
      LEFT OUTER JOIN (
          SELECT *
          FROM Q_points
          WHERE user_id = ?
      ) AS p ON q.question_id = p.question_id
      WHERE t.content = ?`;
      if (answered == 'answered') {
        query += ' AND q.answered = 1';
      } else if (answered == 'unanswered') {
        query += ' AND q.answered = 0';
      }
      if (sorting == 'recent') {
        query += ' ORDER BY timestamp DESC';
      } else if (sorting == 'popular') {
        query += ` AND timestamp >= DATE_SUB(CURDATE(), INTERVAL ${interval} DAY)`;
        query += ' ORDER BY upvotes DESC';
      } else if (sorting == 'topAllTime') {
        query += ' ORDER BY upvotes DESC';
      }
      query += ` LIMIT ${limit};`;
      query += 'SELECT * FROM Tags;';
      pool.query(query, [user_id, tag], (error, results: RowDataPacket[]) => {
        if (error) return reject(error);
        results[0].map((question: Question) => {
          question.tags = [];
          results[1].map((tag: any) =>
            question.question_id == tag.question_id ? question.tags?.push(tag.content) : '',
          );
        });
        resolve(results[0] as Question[]);
      });
    });
  }

  /**
   * Create new question having the given title.
   *
   * Resolves the newly created question id.
   */
  create(title: string, content: string, user_id: number, tags: Tag[]) {
    return new Promise<number>((resolve, reject) => {
      var query = `INSERT INTO Questions(title, content, timestamp, user_id) VALUES (?, ?, ?, ?);
      SET @insert_id = LAST_INSERT_ID();`;
      for (let tag of tags) {
        query += `
        INSERT INTO Tags (question_id, content) VALUES (@insert_id, '${tag.content}');`;
      }
      pool.query(
        query,
        [title, cleanInput(content), new Date(), user_id],
        (error, results: ResultSetHeader) => {
          if (error) return reject(error);
          resolve(results.insertId);
        },
      );
    });
  }

  /**
   * Delete question with given id.
   */
  delete(question_id: number, user_id: number) {
    //this method does not delete the row in the table, but wipes the content
    //this is because of dependencies
    return new Promise<any>((resolve, reject) => {
      pool.query(
        `SET @user_id = ?;
        SET @question_id = ?;
        SET @owner = (SELECT user_id FROM Questions WHERE question_id = @question_id);
        SELECT IF(
          @user_id = @owner,
          @delete_query := "UPDATE Questions SET upvotes = 0, title = '[deleted]', content = '[deleted]', user_id = 1 WHERE question_id = @question_id;",
          @delete_query := "RETURN 1;"
        );
        PREPARE delete_question FROM @delete_query;
        EXECUTE delete_question;
        DEALLOCATE PREPARE delete_question;
        DELETE FROM Tags WHERE question_id = @question_id;
        `,
        [user_id, question_id],
        (error, results: ResultSetHeader) => {
          if (error) return reject(error);
          resolve(results);
        },
      );
    });
  }

  update(user_id: number, question: Question) {
    return new Promise<any>((resolve, reject) => {
      pool.query(
        `SET @user_id = ?;
        SET @question_id = ?;
        SET @owner = (SELECT user_id FROM Questions WHERE question_id = @question_id);
        SELECT IF(
          @user_id = @owner,
          @edit_query := "UPDATE Questions SET title=?, content=?, answered=? WHERE question_id = @question_id;",
          @edit_query := "RETURN 1;"
        );
        PREPARE edit_question FROM @edit_query;
        EXECUTE edit_question;
        DEALLOCATE PREPARE edit_question;
        
        -- UPDATE Questions SET title=?, content=?, answered=? WHERE question_id = @question_id;`,
        [
          user_id,
          question.question_id,
          cleanInput(question.title),
          cleanInput(question.content),
          question.answered,
        ],
        (error, results) => {
          if (error) {
            return reject(error);
          }
          resolve(results);
        },
      );
    });
  }

  upvote(question_id: number, user_id: number) {
    return new Promise<any>((resolve, reject) => {
      const query = `
      SET @question_id=?;

      SET @user_id = ?;

      SET @current_vote = (
        SELECT upvote
        FROM Q_points
        WHERE
            question_id = @question_id
            AND user_id = @user_id
      );

      SET @prior_vote = (SELECT IF(@current_vote < 2, 1,0));

      SELECT
        IF(
          @prior_vote = 1,
          IF(
            @current_vote = 1,
            @vote_query := 'UPDATE Questions SET upvotes = upvotes - 1 WHERE question_id = @question_id',
            @vote_query := 'UPDATE Questions SET upvotes = upvotes + 2 WHERE question_id = @question_id'
          ),
          @vote_query := 'UPDATE Questions SET upvotes = upvotes + 1 WHERE question_id = @question_id'
        );

      PREPARE update_points FROM @vote_query;
      EXECUTE update_points;
      DEALLOCATE PREPARE update_points;

      SELECT
        IF(
          @prior_vote = 1,  
          IF(
            @current_vote = 1,
            @vote_query := 'DELETE FROM Q_points WHERE user_id = @user_id AND question_id = @question_id',
            @vote_query := 'UPDATE Q_points SET upvote = 1 WHERE user_id = @user_id AND question_id = @question_id'
          ),
          @vote_query := 'INSERT INTO Q_points (user_id, question_id, upvote) VALUES (@user_id, @question_id, 1)'
        );

      PREPARE register_vote FROM @vote_query;
      EXECUTE register_vote;
      DEALLOCATE PREPARE register_vote;
      `;
      pool.query(query, [question_id, user_id], (error, results) => {
        if (error) return reject(error);

        resolve(results);
      });
    });
  }

  downvote(question_id: number, user_id: number) {
    return new Promise<any>((resolve, reject) => {
      const query = `
      SET @question_id=?;

      SET @user_id = ?;

      SET @current_vote = (
        SELECT upvote
        FROM Q_points
        WHERE
            question_id = @question_id
            AND user_id = @user_id
      );

      SET @prior_vote = (SELECT IF(@current_vote < 2, 1,0));

      SELECT
        IF(
          @prior_vote = 1,
          IF(
            @current_vote = 1,
            @vote_query := 'UPDATE Questions SET upvotes = upvotes - 2 WHERE question_id = @question_id',
            @vote_query := 'UPDATE Questions SET upvotes = upvotes + 1 WHERE question_id = @question_id'
          ),
          @vote_query := 'UPDATE Questions SET upvotes = upvotes - 1 WHERE question_id = @question_id'
        );

      PREPARE update_points FROM @vote_query;

      EXECUTE update_points;

      DEALLOCATE PREPARE update_points;

      SELECT
        IF(
          @prior_vote = 1,
          IF(
            @current_vote = 1,
            @vote_query := 'UPDATE Q_points SET upvote = 0 WHERE user_id = @user_id AND question_id = @question_id',
            @vote_query := 'DELETE FROM Q_points WHERE user_id = @user_id AND question_id = @question_id'
          ),
          @vote_query := 'INSERT INTO Q_points (user_id, question_id, upvote) VALUES (@user_id, @question_id, 0)'
        );

      PREPARE register_vote FROM @vote_query;

      EXECUTE register_vote;

      DEALLOCATE PREPARE register_vote;
      `;
      pool.query(query, [question_id, user_id], (error, results) => {
        if (error) return reject(error);
        resolve(results);
      });
    });
  }

  newComment(question_id: number, user_id: number, content: string) {
    return new Promise<any>((resolve, reject) => {
      var query = `INSERT INTO Q_comments (question_id, user_id, content, timestamp) VALUES (?,?,?,?);`;
      pool.query(
        query,
        [question_id, user_id, cleanInput(content), new Date()],
        (error, results: ResultSetHeader) => {
          if (error) return reject(error);
          resolve(results);
        },
      );
    });
  }

  editComment(user_id: number, comment: Q_comment) {
    const query = `SET @user_id = ?;
        SET @comment_id = ?;
        SET @owner = (SELECT user_id FROM Q_comments WHERE comment_id = @comment_id);
        SELECT IF(
          @user_id = @owner,
          @edit_query := "UPDATE Q_comments SET content=? WHERE comment_id = @comment_id;",
          @edit_query := "RETURN 1;"
        );
        PREPARE edit_comment FROM @edit_query;
        EXECUTE edit_comment;
        DEALLOCATE PREPARE edit_comment;`;
    return new Promise<any>((resolve, reject) => {
      pool.query(
        query,
        [user_id, comment.comment_id, cleanInput(comment.content)],
        (error, results) => {
          if (error) return reject(error);

          resolve(results);
        },
      );
    });
  }

  deleteComment(user_id: number, comment_id: number) {
    const query = `SET @user_id = ?;
        SET @comment_id = ?;
        SET @owner = (SELECT user_id FROM Q_comments WHERE comment_id = @comment_id);
        SELECT IF(
          @user_id = @owner,
          @edit_query := "DELETE FROM Q_comments WHERE comment_id = @comment_id;",
          @edit_query := "RETURN 1;"
        );
        PREPARE edit_comment FROM @edit_query;
        EXECUTE edit_comment;
        DEALLOCATE PREPARE edit_comment;`;
    return new Promise<any>((resolve, reject) => {
      pool.query(query, [user_id, comment_id], (error, results) => {
        if (error) return reject(error);
        resolve(results);
      });
    });
  }

  selectBestAnswer(user_id: number, answer_id: number) {
    const query = `
    SET @user_id = ?;
    SET @answer_id = ?;      
    SET @question_id = (
            SELECT question_id
            FROM Answers
            WHERE
                answer_id = @answer_id
        );    
    SET @owner = (
            SELECT user_id
            FROM Questions
            WHERE
                question_id = @question_id
        );    
    SELECT
        IF(
            @user_id = @owner,
            @permission_query := "SELECT 'Har ikke noe lurt å si her, skal bare ikke returne';",
            @permission_query := "RETURN 1;"
        );        
    PREPARE permission_exec FROM @permission_query;        
    EXECUTE permission_exec;        
    DEALLOCATE PREPARE permission_exec;        
    SET @prior_best = (
            SELECT answer_id
            FROM Answers
            WHERE
                question_id = @question_id
                AND best_answer = 1
        );    
    SELECT
        IF(
            @prior_best > 0,
            @reset_query := 'UPDATE Answers SET best_answer = 0 WHERE answer_id = @prior_best',
            @reset_query := 'SELECT "No prior best answer"'
        );        
    PREPARE reset_best_answer FROM @reset_query;        
    EXECUTE reset_best_answer;        
    DEALLOCATE PREPARE reset_best_answer;        
    UPDATE Questions SET answered = 1 WHERE question_id = @question_id;        
    UPDATE Answers SET best_answer = 1 WHERE answer_id = @answer_id;`;
    return new Promise<any>((resolve, reject) => {
      pool.query(query, [user_id, answer_id], (error, results) => {
        if (error) return reject(error);
        resolve(results);
      });
    });
  }

  unselectBestAnswer(user_id: number, answer_id: number) {
    const query = `
    SET @user_id = ?;
    SET @answer_id = ?;      
    SET @question_id = (
            SELECT question_id
            FROM Answers
            WHERE
                answer_id = @answer_id
        );    
    SET @owner = (
            SELECT user_id
            FROM Questions
            WHERE
                question_id = @question_id
        );    
    SELECT
        IF(
            @user_id = @owner,
            @permission_query := "SELECT 'Har ikke noe lurt å si her, skal bare ikke returne';",
            @permission_query := "RETURN 1;"
        );        
    PREPARE permission_exec FROM @permission_query;        
    EXECUTE permission_exec;        
    DEALLOCATE PREPARE permission_exec;        
    UPDATE Questions SET answered = 0 WHERE question_id = @question_id;        
    UPDATE Answers SET best_answer = 0 WHERE answer_id = @answer_id;`;
    return new Promise<any>((resolve, reject) => {
      pool.query(query, [user_id, answer_id], (error, results) => {
        if (error) return reject(error);
        resolve(results);
      });
    });
  }

  saveQuestion(user_id: number, question_id: number) {
    const query = `
    SET @user_id = ?;
    SET @question_id = ?;
    SELECT IF( (
            SELECT count(*)
            FROM User_saved
            WHERE
                user_id = @user_id
                AND question_id = @question_id
        ) > 0,
        @prompt := "SELECT 'Already saved'",
        @prompt := "INSERT INTO User_saved (user_id, question_id) VALUES (@user_id,@question_id);"
    );
    PREPARE exec FROM @prompt;
    EXECUTE exec;
    DEALLOCATE PREPARE exec;`;
    return new Promise<any>((resolve, reject) => {
      pool.query(query, [user_id, question_id], (error, results) => {
        if (error) return reject(error);
        resolve(results);
      });
    });
  }

  unsaveQuestion(user_id: number, question_id: number) {
    const query = `DELETE FROM User_saved WHERE user_id = ? AND question_id = ?;`;
    return new Promise<any>((resolve, reject) => {
      pool.query(query, [user_id, question_id], (error, results) => {
        if (error) return reject(error);
        resolve(results);
      });
    });
  }

  getSavedQuestions(user_id: number) {
    const query = `
    SET @user_id = ?;

    SELECT
        q.*
    FROM
        User_saved AS us
    JOIN
        Questions AS q ON us.question_id = q.question_id
    WHERE
        us.user_id = @user_id;
    `;
    return new Promise<Question[]>((resolve, reject) => {
      pool.query(query, [user_id], (error, results: any) => {
        if (error) return reject(error);
        resolve(results[1] as Question[]);
      });
    });
  }
}

const questionServices = new QuestionServices();
export default questionServices;
