import express, { NextFunction, Request, Response } from 'express';
import passport from 'passport';
import { Strategy as LocalStrategy } from 'passport-local';
import bcrypt from 'bcryptjs';
import { userServices } from './services/userServices';
import sessionMiddleware from './sessionConfig';
import authRouter from './routes/authRouter';

const app = express();

app.use(express.json());

app.use(sessionMiddleware);

// MiddleWare for testing
const authTestMiddleware = (req: Request, _res: Response, next: NextFunction) => {
  if (process.env.TESTING) {
    req.user = { user_id: 2 };
    return next();
  }
  next();
};

app.use(authTestMiddleware);

// Initialize passort
app.use(passport.initialize());
app.use(passport.session());

app.use(authRouter);

// Local passport strategy for local user authentication
passport.use(
  new LocalStrategy(async (username, password, done) => {
    const user = await userServices.getUserByUsername(username);
    if (!user) {
      return done(null, false, { message: 'Incorrect username' });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return done(null, false, { message: 'Incorrect password' });
    }
    return done(null, user);
  }),
);

// Serialize user with only user id
passport.serializeUser((user: any, done) => {
  done(null, user.user_id);
});

// Deserialize user with new database call to get the most recent info
passport.deserializeUser(async (id: number, done) => {
  try {
    const user = await userServices.getUserById(id);
    if (user) {
      done(null, user);
    } else {
      done(null, false);
    }
  } catch (error) {
    done(error);
  }
});

export default app;
