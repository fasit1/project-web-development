import { Router } from 'express';
import { userServices } from '../services/userServices';
import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import dotenv from 'dotenv';
import os from 'os';

if (process.env.NODE_ENV !== 'test') {
  dotenv.config();
}

const getLocalIpAddress = () => {
  const interfaces = os.networkInterfaces();
  for (const interfaceName in interfaces) {
    const interfaceInfo = interfaces[interfaceName];
    if (interfaceInfo) {
      for (const info of interfaceInfo) {
        if (info.family === 'IPv4' && !info.internal) {
          return info.address;
        }
      }
    } else console.error('Interface info not found');
  }
  return;
};

const router = Router();

var callbackUrl = 'http';
if (process.env.HTTPS == 'true') {
  callbackUrl += 's';
}
callbackUrl += '://';
if (process.env.PROD == 'true') {
  callbackUrl += getLocalIpAddress();
  //This gives an error without implementing DNS and updating your Google Apps allowed hosts list.
} else {
  callbackUrl += 'localhost:3000';
}
callbackUrl += '/auth/google/callback';

if (process.env.DOCKER != 'true') {
  passport.use(
    new GoogleStrategy(
      {
        clientID: process.env.GOOGLE_CLIENT_ID as string,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET as string,
        callbackURL: callbackUrl,
        scope: ['profile', 'email', 'photos'],
      },
      function verify(_accessToken: string, _refreshToken: string, profile: any, cb: any) {
        userServices.findOrCreate(
          profile.id,
          profile.displayName,
          profile.emails[0],
          profile._json.picture,
          '',
          function (err, user) {
            return cb(err, user);
          },
        );
      },
    ),
  );

  router.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

  router.get(
    '/auth/google/callback',
    passport.authenticate('google', { failureRedirect: '/login' }),
    function (req, res) {
      // Successful authentication, redirect home.
      res.redirect('/#/');
    },
  );
}

// Posts logout, to log the user out
// Redirects
router.post('/logout', function (req, res, next) {
  req.logout(function (err) {
    if (err) {
      return next(err);
    }
    res.redirect('/');
  });
});

export default router;
