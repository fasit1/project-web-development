import express, { NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import passport from 'passport';
import { userServices } from '../services/userServices';
import { User } from '../../../client/src/components/customTypes';
import questionServices from '../services/questionServices';
import answerServices from '../services/answerServices';
import tagServices from '../services/tagServices';

const router = express.Router();

//
// questions:
//
router.get('/questions/every', async (_request, response) => {
  try {
    const questions = await questionServices.getEveryQuestion();
    response.status(200).send(questions);
  } catch (error) {
    response.status(500).send(error);
  }
});

router.get('/questions/saved', async (request, response) => {
  const user = request.user as User;
  if (user == undefined) {
    // Requests that require a user to be signed in return if the request does not contain a user
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const questions = await questionServices.getSavedQuestions(user_id);
    response.status(200).send(questions);
  } catch (error) {
    response.status(500).send(error);
  }
});

router.get('/questions/:question_id', async (request, response) => {
  const user = request.user as User;
  const question_id = Number(request.params.question_id);
  var user_id = 1;
  // this sets the user_id to be a non-active user, and is needed for the server side service to determine if a user has upvoted/downvoted a question/answer
  if (request.user != undefined) {
    user_id = user.user_id;
  }
  try {
    const c = await questionServices.getQuestion(question_id, user_id);
    c ? response.status(200).send(c) : response.status(404).send('Question not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.get('/questions/all/:sorting/:answered', async (request, response) => {
  const user = request.user as User;
  const sorting = request.params.sorting;
  const answered = request.params.answered;
  var user_id = 1;
  // see comment line 45
  if (request.user != undefined) {
    user_id = user.user_id;
  }
  try {
    const c = await questionServices.getAllQuestions(sorting, answered, user_id);
    c ? response.status(200).send(c) : response.status(404).send('Questions not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.get('/questions/bytag/:tag/:sorting/:answered', async (request, response) => {
  const user = request.user as User;
  const tag = request.params.tag;
  const sorting = request.params.sorting;
  const answered = request.params.answered;
  var user_id = 1;
  // see comment line 45
  if (request.user != undefined) {
    user_id = user.user_id;
  }
  try {
    const c = await questionServices.getQuestionsByTag(tag, sorting, answered, user_id);
    c ? response.status(200).send(c) : response.status(404).send('Questions not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.post('/questions/new/question', async (request, response) => {
  const user = request.user as User;
  const data = request.body;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.create(data.title, data.content, user_id, data.tags);
    response.status(201).send(c);
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/questions/update/question', async (request, response) => {
  const user = request.user as User;
  const data = request.body;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.update(user_id, data);
    c ? response.status(200).send(c) : response.status(404).send('Question not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.delete('/questions/delete/question/:question_id', async (request, response) => {
  const user = request.user as User;
  const question_id = Number(request.params.question_id);
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.delete(question_id, user_id);
    c ? response.status(200).send(c) : response.status(404).send('Question not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/questions/upvote/:question_id', async (request, response) => {
  const user = request.user as User;
  const question_id = Number(request.params.question_id);
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.upvote(question_id, user_id);
    c ? response.status(200).send(c) : response.status(404).send('Question not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/questions/downvote/:question_id', async (request, response) => {
  const user = request.user as User;
  const question_id = Number(request.params.question_id);
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.downvote(question_id, user_id);
    response.status(200).send(c);
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/questions/update/answers/best', async (request, response) => {
  const user = request.user as User;
  const answer_id = request.body.answer_id;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.selectBestAnswer(user_id, answer_id);
    c ? response.status(200).send(c) : response.status(404).send('Answer not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/questions/update/answers/best/unselect', async (request, response) => {
  const user = request.user as User;
  const answer_id = request.body.answer_id;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.unselectBestAnswer(user_id, answer_id);
    c ? response.status(200).send(c) : response.status(404).send('Answer not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.post('/questions/save', async (request, response) => {
  const user = request.user as User;
  const question_id = request.body.question_id;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.saveQuestion(user_id, question_id);
    c ? response.status(200).send(c) : response.status(404).send('Question not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.delete('/questions/unsave/:question_id', async (request, response) => {
  const user = request.user as User;
  const question_id = Number(request.params.question_id);
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.unsaveQuestion(user_id, question_id);
    c ? response.status(200).send(c) : response.status(404).send('Question not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

//
// answers:
//
router.post('/answers/new/answer/', async (request, response) => {
  const user = request.user as User;
  const data = request.body;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await answerServices.create(data.question_id, user_id, data.content);
    response.status(201).send(c);
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/answers/update/answer', async (request, response) => {
  const user = request.user as User;
  const data = request.body;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await answerServices.update(user_id, data);
    c ? response.status(200).send(c) : response.status(404).send('Answer not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.delete('/answers/delete/answer/:answer_id', async (request, response) => {
  const user = request.user as User;
  const answer_id = Number(request.params.answer_id);
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await answerServices.delete(user_id, answer_id);
    c ? response.status(200).send(c) : response.status(404).send('Answer not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/answers/upvote/:answer_id', async (request, response) => {
  const answer_id = Number(request.params.answer_id);
  const user = request.user as User;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await answerServices.upvote(answer_id, user_id);
    c ? response.status(200).send(c) : response.status(404).send('Answer not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/answers/downvote/:answer_id', async (request, response) => {
  const answer_id = Number(request.params.answer_id);
  const user = request.user as User;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await answerServices.downvote(answer_id, user_id);
    c ? response.status(200).send(c) : response.status(404).send('Answer not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

//
// comments:
//
router.post('/answers/new/comment', async (request, response) => {
  const data = request.body;
  const user = request.user as User;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await answerServices.newComment(data.answer_id, user_id, data.content);
    response.status(201).send(c);
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/answers/update/comment', async (request, response) => {
  const data = request.body;
  const user = request.user as User;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await answerServices.editComment(user_id, data.comment);
    c ? response.status(200).send(c) : response.status(404).send('Comment not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.delete('/answers/delete/comment/:comment_id', async (request, response) => {
  const comment_id = Number(request.params.comment_id);
  const user = request.user as User;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await answerServices.deleteComment(user_id, comment_id);
    c ? response.status(200).send(c) : response.status(404).send('Comment not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.post('/questions/new/comment', async (request, response) => {
  const data = request.body;
  const user = request.user as User;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.newComment(data.question_id, user_id, data.content);
    response.status(201).send(c);
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/questions/update/comments', async (request, response) => {
  const data = request.body;
  const user = request.user as User;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.editComment(user_id, data.comment);
    c ? response.status(200).send(c) : response.status(404).send('Comment not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.delete('/questions/delete/comment/:comment_id', async (request, response) => {
  const comment_id = Number(request.params.comment_id);
  const user = request.user as User;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await questionServices.deleteComment(user_id, comment_id);
    c ? response.status(200).send(c) : response.status(404).send('Comment not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

//
// tags:
//
router.get('/tags/favorites', async (request, response) => {
  const user = request.user as User;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await tagServices.getFavorites(user_id);
    c ? response.status(200).send(c) : response.status(404).send('Comment not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.get('/tags/popular', async (_request, response) => {
  try {
    const c = await tagServices.getPopular();
    c ? response.status(200).send(c) : response.status(404).send('Comment not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.get('/tags/all', async (_request, response) => {
  try {
    const c = await tagServices.getAll();
    c ? response.status(200).send(c) : response.status(404).send('Comment not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.post('/tags/favorites', async (request, response) => {
  const user = request.user as User;
  const tag = request.body;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await tagServices.addToFavorites(user_id, tag);
    response.status(200).send(c);
  } catch (error) {
    response.status(500).send(error);
  }
});

router.delete('/tags/favorites/:tag', async (request, response) => {
  const user = request.user as User;
  const tag = request.params.tag;
  if (user == undefined) {
    response.status(401).send('No user for request');
    return;
  }
  const user_id = user.user_id;
  try {
    const c = await tagServices.removeFromFavorites(user_id, tag);
    c ? response.status(200).send(c) : response.status(404).send('Favorite tag not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

//
// login:
//
router.post('/login', async (request, response, next) => {
  passport.authenticate('local', (error: any, user: User, info: any) => {
    if (error) {
      return next(error);
    }
    if (!user) {
      // Authentication failed
      return response.status(401).send({ message: info.message });
    }
    request.logIn(user, (error) => {
      if (error) {
        return next(error);
      }
      // Authentication succeeded
      return response.send({ message: 'Login successful', user: user });
    });
  })(request, response, next);
});

//
// users:
//
router.post('/users/create', async (request, response) => {
  const { username, password, email, firstName, lastName } = request.body;

  //check if username and password are provided
  if (!username || !password || !email || !firstName || !lastName) {
    return response.status(400).send({ message: 'Username, password and email are required.' });
  }

  //check if username is taken
  const existingUsername = await userServices.getUserByUsername(username);
  if (existingUsername) {
    return response.status(400).send({ message: 'Username already taken.' });
  }

  //check if email is in use
  const existingEmail = await userServices.getUserByEmail(email);
  if (existingEmail) {
    return response.status(400).send({ message: 'Email already in use.' });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  //try saving user to database
  try {
    await userServices.createUser(username, hashedPassword, email, firstName, lastName);
    return response.status(201).send({ message: 'User registered successfully.' });
  } catch (error) {
    return response.status(400).send({ message: `User registered failed, error: ${error}` });
  }
});

function checkAuthentication(request: any, response: any, next: NextFunction) {
  if (request.isAuthenticated()) {
    return next();
  }
  response.status(401).send('Not authenticated');
}

router.get('/users/authenticate/user', async (request, response) => {
  if (request.isAuthenticated()) {
    response.send({ authenticated: true });
  } else {
    response.status(200).json({ authenticated: false });
  }
});

router.get('/users/get/self', checkAuthentication, async (request, response) => {
  const { username, user_id, fullname, email, about_me } = request.user as User;
  const formattedUser = { username, user_id, fullname, email, about_me };
  response.send({ user: formattedUser });
});

router.get('/logout', async (request, response) => {
  request.logout((done) => {
    // Check if the session exists
    if (request.session) {
      // Destroy session data
      request.session.destroy((err) => {
        if (err) {
          response.send({ success: false, message: 'Failed to logout, please try again.' });
        } else {
          response.clearCookie('connect.sid'); // Clear cookie
          response.send({ success: true, message: 'Successfully logged out' });
        }
      });
    } else {
      response.send({ success: false, message: 'You are not logged in.' });
    }
  });
});

router.get('/users/get/:user_id/content/all', async (request, response) => {
  const user_id = Number(request.params.user_id);
  try {
    const c = await userServices.getContentByUserId(user_id);
    c ? response.send(c) : response.status(404).send('User not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.get('/users/:username', async (request, response) => {
  const username = request.params.username;
  try {
    const c = await userServices.getUserByUsername(username);
    c ? response.send(c) : response.status(404).send('User not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.delete('/users/:user_id/delete', async (request, response) => {
  const user_id = Number(request.params.user_id);
  try {
    if (user_id != (request.user as User).user_id) throw 'unathorized delete';
    const c = await userServices.deleteUser(user_id);
    c ? response.status(200).send(c) : response.status(404).send('User not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

router.get('/users/search/all', async (_request, response) => {
  try {
    const c = await userServices.getAllUsernames();
    response.status(200).send(c);
  } catch (error) {
    response.status(500).send(error);
  }
});

router.put('/users/update', async (request, response) => {
  const data = request.body;
  try {
    const c = await userServices.updateUser(data);
    c ? response.status(200).send(c) : response.status(404).send('User not found');
  } catch (error) {
    response.status(500).send(error);
  }
});

export { router };
