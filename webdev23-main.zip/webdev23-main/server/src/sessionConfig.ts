import expressSession from 'express-session';
import crypto from 'crypto';

const sessionMiddleware = expressSession({
  //this secret is created randomly, to remain secret
  secret: Math.random().toString(16),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.HTTPS === 'true', // Set to true if https is on
    maxAge: 60 * 60 * 1000, // 1 hour
  },
});

export default sessionMiddleware;
