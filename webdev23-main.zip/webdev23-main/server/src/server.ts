import app from './app';
import express from 'express';
import path from 'path';
import https from 'https';
import http from 'http';
import fs from 'fs';
import { router } from './routes/apiRouter';
import dotenv from 'dotenv';
import os from 'os';

// call dotenv.config() if tests are running
if (process.env.NODE_ENV !== 'test') {
  dotenv.config();
}

const basePath = '/api/v1';

// Serve client files
app.use(express.static(path.join(__dirname, '/../../client/public')));

app.use(basePath, router);

var port = 3000;
var localAddress = 'localhost:3000';

// Get machines IP address
const getLocalIpAddress = () => {
  const interfaces = os.networkInterfaces();
  for (const interfaceName in interfaces) {
    const interfaceInfo = interfaces[interfaceName];
    if (interfaceInfo) {
      for (const info of interfaceInfo) {
        if (info.family === 'IPv4' && !info.internal) {
          return info.address;
        }
      }
    } else console.error('Interface info not found');
  }
  return;
};

const https_server = process.env.HTTPS == 'true' ? true : false;

// Set correct port depending of prod
if (process.env.PROD == 'true') {
  port = https_server ? 443 : 80;
  localAddress =
    process.env.DOCKER == 'true'
      ? JSON.stringify(process.env.MYSQL_HOST)
      : (getLocalIpAddress() as string);
}

let webServer: http.Server | https.Server;

//Toggle between http and https
if (https_server) {
  // SSL certificate
  const privateKey = fs.readFileSync(path.join(__dirname, '../ssl/private.key'), 'utf8');
  const certificate = fs.readFileSync(path.join(__dirname, '../ssl/certificate.crt'), 'utf8');

  const credentials = { key: privateKey, cert: certificate };

  webServer = https.createServer(credentials, app);

  webServer.listen(port, () => {
    console.info(
      `Server running on HTTPS on port ${port}, access: https://${localAddress}`,
      basePath,
    );
  });
} else {
  webServer = http.createServer(app);

  webServer.listen(port, () => {
    console.info(
      `Server running on HTTP on port ${port}, access: http://${localAddress}`,
      basePath,
    );
  });
}

export default webServer;
