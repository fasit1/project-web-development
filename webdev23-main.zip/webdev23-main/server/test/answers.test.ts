import axios from 'axios';
import pool from '../src/mysql-pool';
import webServer from '../src/server';
import query from './reset_db';
import answerServices from '../src/services/answerServices';

process.env.TESTING = 'true';

jest.spyOn(console, 'info').mockImplementation((text) => {}); //avoids unnecessary console output

axios.defaults.baseURL = `http://localhost:${process.env.PORT}/api/v1`;

beforeAll(async () => {
  // Execute database query
  await new Promise((resolve, reject) => {
    pool.query(query, (error, results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });

  // Wait for the web server to start
  if (!webServer.listening) {
    await new Promise((resolve) => webServer.on('listening', resolve));
  }
});

beforeEach(() => {
  jest.clearAllMocks();
});

afterAll((done) => {
  if (webServer) {
    webServer.close(() => {
      if (pool.end && typeof pool.end === 'function') {
        pool.end((error) => {
          if (error) {
            console.error('Feil under lukking av webserver:', error);
            return done(error);
          }
          done();
        });
      } else {
        console.error('Pool har ingen end-metode eller er ikke en funksjon');
        done();
      }
    });
  } else {
    done(new Error('Web server not available'));
  }
});

describe('/answers/new/answer', () => {
  test('create answer (201)', async () => {
    const response = await axios.post('/answers/new/answer', {
      question_id: 1,
      content: 'new content',
    });
    expect(response.status).toBe(201);
  });
  test('error 500', async () => {
    answerServices.create = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.post('/answers/new/answer', {
        question_id: 1,
        content: 'new content',
      });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/answers/update/answer', () => {
  test('update answer (200)', async () => {
    const response = await axios.put('/answers/update/answer', {
      answer_id: 1,
      content: 'new content',
    });
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    answerServices.update = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.put('/answers/update/answer', {
        answer_id: 1,
        content: 'new content',
      });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/answers/delete/answer/:answer_id', () => {
  test('delete answer (200)', async () => {
    const response = await axios.delete('/answers/delete/answer/1');
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    answerServices.delete = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.delete('/answers/delete/answer/1');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/answers/upvote/:answer_id', () => {
  test('upvote answer (200)', async () => {
    const response = await axios.put('/answers/upvote/1');
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    answerServices.upvote = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.put('/answers/upvote/1');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/answers/downvote/:answer_id', () => {
  test('downvote answer (200)', async () => {
    const response = await axios.put('/answers/downvote/1');
    expect(response.status).toBe(200);
  });
  test('answer not found (404)', async () => {});
  test('error 500', async () => {
    answerServices.downvote = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.put('/answers/downvote/1');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/answers/new/comment', () => {
  test('new comment (201)', async () => {
    const response = await axios.post('/answers/new/comment', {
      answer_id: 1,
      content: 'new content',
    });
    expect(response.status).toBe(201);
  });
});
