import { userServices } from '../src/services/userServices';
import axios from 'axios';
import pool from '../src/mysql-pool';
import webServer from '../src/server';
import query from './reset_db';
import tagServices from '../src/services/tagServices';

process.env.NODE_ENV = 'test';
process.env.TESTING = 'true';

jest.spyOn(console, 'info').mockImplementation((text) => {}); //avoids unnecessary console output

axios.defaults.baseURL = `http://localhost:${process.env.PORT}/api/v1`;

beforeAll(async () => {
  // Execute database query
  await new Promise((resolve, reject) => {
    pool.query(query, (error, results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });

  // Wait for the web server to start
  if (!webServer.listening) {
    await new Promise((resolve) => webServer.on('listening', resolve));
  }
});

beforeEach(() => {
  jest.clearAllMocks();
});

afterAll((done) => {
  if (webServer) {
    webServer.close(() => {
      if (pool.end && typeof pool.end === 'function') {
        pool.end((error) => {
          if (error) {
            console.error('Feil under lukking av webserver:', error);
            return done(error);
          }
          done();
        });
      } else {
        console.error('Pool har ingen end-metode eller er ikke en funksjon');
        done();
      }
    });
  } else {
    done(new Error('Web server not available'));
  }
});

describe('/tags/favorites', () => {
  test('get favorites tags (200)', async () => {
    const response = await axios.get('/tags/favorites');
    expect(response.status).toBe(200);

    expect(Array.isArray(response.data)).toBeTruthy();

    response.data.forEach((tag: any) => {
      expect(tag).toHaveProperty('content');
    });
  });
  test('error 500', async () => {
    tagServices.getFavorites = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.get('/tags/favorites');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/tags/popular', () => {
  test('get popular tags (200)', async () => {
    const response = await axios.get('/tags/popular');
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    tagServices.getPopular = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.get('/tags/popular');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/tags/all', () => {
  test('get all tags (200)', async () => {
    const response = await axios.get('/tags/all');
    expect(response.status).toBe(200);
  });

  test('error 500', async () => {
    tagServices.getAll = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.get('/tags/all');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/tags/favorites', () => {
  test('successful addition of a tag', async () => {
    const response = await axios.post('/tags/favorites', { content: 'python' });
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    tagServices.addToFavorites = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.post('/tags/favorites', { tagToAdd: 'mockTag' });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/tags/favorites/:tag', () => {
  test('successful deletion of a tag', async () => {
    const response = await axios.delete(`/tags/favorites/'web-app-security'`);
    expect(response.status).toBe(200);
  });

  jest.mock('../src/services/userServices');
  test('error 500', async () => {
    tagServices.removeFromFavorites = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.delete(`/tags/favorites/3`);
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });

  jest.mock('../src/services/userServices');
  test('favorite tag not found', async () => {
    //@ts-ignore
    userServices.getAllUsernames = jest.fn(() => Promise.reject(new Error({ status: 404 })));
    try {
      const response = await axios.get('/tags/favorites/3');
    } catch (error: any) {
      expect(error.response.status).toEqual(404);
    }
  });
});
