import axios from 'axios';
import pool from '../src/mysql-pool';
import webServer from '../src/server';
import query from './reset_db';
import { Question } from '../../client/src/components/customTypes';
import questionServices from '../src/services/questionServices';

process.env.NODE_ENV = 'test';
process.env.TESTING = 'true';

jest.spyOn(console, 'info').mockImplementation((text) => {}); //avoids unnecessary console output

// console.log(process.env.PORT);
axios.defaults.baseURL = `http://localhost:${process.env.PORT}/api/v1`;

beforeAll(async () => {
  // Execute database query
  await new Promise((resolve, reject) => {
    pool.query(query, (error, results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });

  // Wait for the web server to start
  if (!webServer.listening) {
    await new Promise((resolve) => webServer.on('listening', resolve));
  }
});

beforeEach(() => {
  jest.clearAllMocks();
});

afterAll((done) => {
  if (webServer) {
    webServer.close(() => {
      if (pool.end && typeof pool.end === 'function') {
        pool.end((error) => {
          if (error) {
            console.error('Feil under lukking av webserver:', error);
            return done(error);
          }
          done();
        });
      } else {
        console.error('Pool har ingen end-metode eller er ikke en funksjon');
        done();
      }
    });
  } else {
    done(new Error('Web server not available'));
  }
});

describe('Testing multiple questions handling', () => {
  test('Get every question (for search)', (done) => {
    axios
      .get('/questions/every')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        expect(response.data[0].question_id).toBe(1);
        done();
      })
      .catch((error) => {
        console.error(error);
        done(error);
      });
  });
  test('Get every question, popular, answered', (done) => {
    axios
      .get('/questions/all/popular/answered')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        expect(response.data[0].question_id).toBe(2);
        done();
      })
      .catch((error) => {
        console.error(error);
        done(error);
      });
  });

  test('Get every question, popular, unanswered', (done) => {
    axios
      .get('/questions/all/popular/unanswered')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        expect(response.data.length).toBe(6);
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
  test('Get every question, popular, scrambled', (done) => {
    axios
      .get('/questions/all/popular/scrambled')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        expect(response.data[0].question_id).toBe(2);
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
  test('Get every question, recent, answered', (done) => {
    axios
      .get('/questions/all/recent/answered')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        expect(response.data[0].question_id).toBe(1);
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
  test('Get every question, recent, unanswered', (done) => {
    axios
      .get('/questions/all/recent/unanswered')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        expect(response.data.length).toBe(7);
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
  test('Get every question, recent, scrambled', (done) => {
    axios
      .get('/questions/all/recent/scrambled')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        expect(response.data[0].question_id).toBe(1);
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
});

describe('Testing multiple questions handling', () => {
  test('Get every question (for search)', (done) => {
    axios
      .get('/questions/every')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
  test('Get every question, popular, answered', (done) => {
    axios
      .get('/questions/all/popular/answered')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
  test('Get every question, popular, unanswered', (done) => {
    axios
      .get('/questions/all/popular/unanswered')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
  test('Get every question, popular, scrambled', (done) => {
    axios
      .get('/questions/all/popular/scrambled')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
  test('Get every question, recent, answered', (done) => {
    axios
      .get('/questions/all/recent/answered')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
  test('Get every question, recent, unanswered', (done) => {
    axios
      .get('/questions/all/recent/unanswered')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
  test('Get every question, recent, scrambled', (done) => {
    axios
      .get('/questions/all/recent/scrambled')
      .then((response) => {
        expect(response.status).toBe(200);
        response.data.map((question: Question) => {
          expect(question.question_id).toBeDefined();
          expect(question.title).toBeDefined();
          expect(question.content).toBeDefined();
          expect(question.timestamp).toBeDefined();
          expect(question.answered).toBeDefined();
          expect(question.user_id).toBeDefined();
          expect(question.upvotes).toBeDefined();
        });
        done();
      })
      .catch((error) => {
        done(error);
      });
  });
});

describe('/questions/:question_id', () => {
  test('get question by id (200)', async () => {
    const response = await axios.get('/questions/3');
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    questionServices.getQuestion = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.get('/questions/1');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('questions/bytag/:bytag/:sorting/:answered (500)', () => {
  test('get every tag, popular, answered', async () => {
    let tag = 'every';
    jest.spyOn(questionServices, 'getQuestionsByTag').mockRejectedValue(new Error('Service error'));

    try {
      await axios.get(`/questions/bytag/${tag}/popular/answered`);
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/new/question', () => {
  let createQuestion = {
    user_id: 2,
    tags: ['oi'],
    title: 'new title',
    content: 'new content',
  };

  test('create question (201)', async () => {
    const response = await axios.post('/questions/new/question', createQuestion);
    expect(response.status).toBe(201);
  });
  test('error 500', async () => {
    questionServices.create = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.post('/questions/new/question', {
        title: 'new title',
        content: 'new content',
      });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/update/question', () => {
  let updateQuestion: Question = {
    user_id: 2,
    question_id: 2,
    title: 'new title',
    content: 'new content',
    answered: true,
    username: 'test',
    upvotes: 0,
    timestamp: '2021-10-10',
    answers: [],
  };
  test('update question (200)', async () => {
    const response = await axios.put('/questions/update/question', updateQuestion);
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    questionServices.update = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.put('/questions/update/question', {
        question_id: 1,
        title: 'new title',
        content: 'new content',
      });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/delete/question/:question_id', () => {
  test('delete question (200)', async () => {
    const response = await axios.delete('/questions/delete/question/2');
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    questionServices.delete = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.delete('/questions/delete/question/1');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/upvote/:question_id', () => {
  test('upvote question (200)', async () => {
    const response = await axios.put('/questions/upvote/2');
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    questionServices.upvote = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.put('/questions/upvote/1');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/downvote/:question_id', () => {
  test('downvote question (200)', async () => {
    const response = await axios.put('/questions/downvote/2');
    expect(response.status).toBe(200);
  });

  test('error 500', async () => {
    questionServices.downvote = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.put('/questions/downvote/1');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/update/answers/best', () => {
  test('error 500', async () => {
    questionServices.selectBestAnswer = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.put('/questions/update/answers/best', { answer_id: 1 });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/update/answers/best/unselect', () => {
  test('error 500', async () => {
    questionServices.unselectBestAnswer = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.put('/questions/update/answers/best/unselect', {
        question_id: 1,
      });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/save/', () => {
  test('save question (200)', async () => {
    const response = await axios.post('/questions/save/', { question_id: 1 });
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    questionServices.saveQuestion = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.post('/questions/save/', { question_id: 1 });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/unsave/:question_id', () => {
  test('unsave question (200)', async () => {
    const response = await axios.delete('/questions/unsave/1');
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    questionServices.unsaveQuestion = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.delete('/questions/unsave/1');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/saved', () => {
  test('Retrieve saved questions  (200)', async () => {
    const response = await axios.get('/questions/saved');
    expect(response.status).toBe(200);
  });
});
