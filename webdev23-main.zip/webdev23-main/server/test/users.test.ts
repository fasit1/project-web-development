import { userServices } from '../src/services/userServices';
import axios, { AxiosError } from 'axios';
import pool from '../src/mysql-pool';
import webServer from '../src/server';
import query from './reset_db';

process.env.NODE_ENV = 'test';
process.env.TESTING = 'true';

jest.spyOn(console, 'info').mockImplementation((text) => {}); //avoids unnecessary console output

axios.defaults.baseURL = `http://localhost:${process.env.PORT}/api/v1`;

beforeAll(async () => {
  // Execute database query
  await new Promise((resolve, reject) => {
    pool.query(query, (error, results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });

  // Wait for the web server to start
  if (!webServer.listening) {
    await new Promise((resolve) => webServer.on('listening', resolve));
  }
});

beforeEach(() => {
  jest.clearAllMocks();
});

afterAll((done) => {
  if (webServer) {
    webServer.close(() => {
      if (pool.end && typeof pool.end === 'function') {
        pool.end((error) => {
          if (error) {
            console.error('Feil under lukking av webserver:', error);
            return done(error);
          }
          done();
        });
      } else {
        console.error('Pool har ingen end-metode eller er ikke en funksjon');
        done();
      }
    });
  } else {
    done(new Error('Web server not available'));
  }
});

describe('/users/create', () => {
  const mockUserData = {
    username: 'newuser1',
    password: 'password123',
    email: 'newuser143@example.com',
    firstName: 'New',
    lastName: 'User',
  };

  const mockUserData2 = {
    username: 'newuser100',
    password: 'password123',
    email: 'newuser100@example.com',
    firstName: 'New',
    lastName: 'User',
  };

  const duplicateEmail = {
    username: 'newuser101',
    password: 'password123',
    email: 'newuser100@example.com',
    firstName: 'New',
    lastName: 'User',
  };

  test('successful user creation', (done) => {
    axios
      .post('/users/create', mockUserData)
      .then((response) => {
        expect(response.status).toBe(201);
        expect(response.data.message).toEqual('User registered successfully.');
        done();
      })
      .catch((error) => {
        // console.error(error);
        done(error);
      });
  });

  test('attempt to create user with existing username', (done) => {
    axios.post('/users/create', mockUserData).catch((error) => {
      expect(error.response.status).toBe(400);
      expect(error.response.data).toEqual({ message: 'Username already taken.' });
      done();
    });
  });

  test('attempt to create user with existing email', (done) => {
    axios.post('/users/create', mockUserData2).then(() => {
      axios.post('/users/create', duplicateEmail).catch((error) => {
        expect(error.response.status).toBe(400);
        expect(error.response.data).toEqual({ message: 'Email already in use.' });
        done();
      });
    });
  });

  test('user registration fails due to service error', async () => {
    jest.spyOn(userServices, 'createUser').mockImplementationOnce(() => {
      throw new Error('Service error');
    });

    let mockUserData3 = {
      username: 'newuser1',
      password: 'password123',
      email: '',
      firstName: 'New',
      lastName: 'User',
    };

    await expect(axios.post('/users/create', mockUserData3)).rejects.toHaveProperty(
      'response.status',
      400,
    );
    await expect(axios.post('/users/create', mockUserData3)).rejects.toHaveProperty(
      'response.data.message',
      'Username, password and email are required.',
    );

    jest.restoreAllMocks();
  });
});

describe('/users/get/:user_id/content/all ', () => {
  test('get content by user id (200)', async () => {
    const response = await axios.get('/users/get/2/content/all');
    expect(response.status).toBe(200);

    // Check the structure of the response
    expect(response.data).toHaveProperty('questions');
    expect(response.data).toHaveProperty('answers');
    expect(response.data).toHaveProperty('q_comments');
    expect(response.data).toHaveProperty('a_comments');
    expect(response.data).toHaveProperty('stats');

    // Check if each property is an array (where applicable)
    expect(Array.isArray(response.data.questions)).toBeTruthy();
    expect(Array.isArray(response.data.answers)).toBeTruthy();
    expect(Array.isArray(response.data.q_comments)).toBeTruthy();
    expect(Array.isArray(response.data.a_comments)).toBeTruthy();

    // Validate the contents of each array
    response.data.questions.forEach((question: any) => {
      expect(question).toHaveProperty('question_id');
      expect(question).toHaveProperty('title');
    });

    response.data.answers.forEach((answer: any) => {
      expect(answer).toHaveProperty('answer_id');
      expect(answer).toHaveProperty('content');
    });

    response.data.q_comments.forEach((comment: any) => {
      expect(comment).toHaveProperty('comment_id');
    });

    response.data.a_comments.forEach((comment: any) => {
      expect(comment).toHaveProperty('comment_id');
    });

    // Validate stats object
    expect(response.data.stats).toHaveProperty('questions');
    expect(response.data.stats).toHaveProperty('answers');
    expect(response.data.stats).toHaveProperty('comments');
    expect(response.data.stats).toHaveProperty('points');
  });

  jest.mock('../src/services/userServices');
  test('fail to get content by user id (500)', async () => {
    userServices.getContentByUserId = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.get('/users/get/2/content/all');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/users/:username', () => {
  test('fail to get user by username', async () => {
    await expect(axios.get('/users/ikkefinne')).rejects.toHaveProperty('response.status', 404);
    await expect(axios.get('/users/ikkefinne')).rejects.toHaveProperty(
      'response.data',
      'User not found',
    );
  });
});

describe('/users/:username', () => {
  test('fail to get user by username', async () => {
    await expect(axios.get('/users/ikkefinne')).rejects.toHaveProperty('response.status', 404);
    await expect(axios.get('/users/ikkefinne')).rejects.toHaveProperty(
      'response.data',
      'User not found',
    );
  });
});

describe('/users/search/all', () => {
  //vet egt ikke om denne tester noe
  test('get all users', async () => {
    const response = await axios.get('/users/search/all');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.data)).toBeTruthy();
    response.data.forEach((user: any) => {
      expect(user).toHaveProperty('username');
    });
  });

  jest.mock('../src/services/userServices');

  test('cant get all users', async () => {
    //@ts-ignore
    userServices.getAllUsernames = jest.fn(() => Promise.reject(new Error({ status: 500 })));
    try {
      const response = await axios.get('/users/search/all');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/users/update', () => {
  let mockUserData5 = {
    username: 'newuser1',
    password: 'password123',
    email: 'jejpo@hoi.no',
    about_me: 'New about me',
    fullname: 'New',
    user_id: 2,
  };

  //oppdaterer ikke brukernavn i databasen
  test('update user (200)', async () => {
    userServices.updateUser = jest.fn(() => Promise.resolve({ status: 200 }));
    const response = await axios.put('/users/update', { mockUserData5 });
    expect(response.status).toBe(200);
  });

  test('error 500', async () => {
    try {
      const response = await axios.put('/users/update', {
        username: 'newuser1',
        password: 'password123',
        email: 'jejpo@hoi.no',
        about_me: 'New about me',
        fullname: 'New',
        user_id: 2000,
      });
    } catch (error: unknown) {
      if (error instanceof AxiosError && error.response) expect(error.response.status).toEqual(500);
    }
  });
});

describe('/users/delete', () => {
  test('update user (200)', async () => {
    const response = await axios.delete('/users/2/delete');
    expect(response.status).toBe(200);
  });
  test('update user (500)', async () => {
    try {
      const response = await axios.delete('/users/1/delete');
    } catch (error: unknown) {
      if (error instanceof AxiosError && error.response) expect(error.response.status).toBe(500);
    }
  });
});
