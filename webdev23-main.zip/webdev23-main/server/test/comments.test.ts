import axios from 'axios';
import pool from '../src/mysql-pool';
import webServer from '../src/server';
import query from './reset_db';
import { A_comment, Q_comment, Question } from '../../client/src/components/customTypes';
import questionServices from '../src/services/questionServices';
import answerServices from '../src/services/answerServices';

process.env.NODE_ENV = 'test';
process.env.TESTING = 'true';

jest.spyOn(console, 'info').mockImplementation((text) => {}); //avoids unnecessary console output

axios.defaults.baseURL = `http://localhost:${process.env.PORT}/api/v1`;

beforeAll(async () => {
  // Execute database query
  await new Promise((resolve, reject) => {
    pool.query(query, (error, results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });

  // Wait for the web server to start
  if (!webServer.listening) {
    await new Promise((resolve) => webServer.on('listening', resolve));
  }
});

beforeEach(() => {
  jest.clearAllMocks();
});

afterAll((done) => {
  if (webServer) {
    webServer.close(() => {
      if (pool.end && typeof pool.end === 'function') {
        pool.end((error) => {
          if (error) {
            console.error('Feil under lukking av webserver:', error);
            return done(error);
          }
          done();
        });
      } else {
        console.error('Pool har ingen end-metode eller er ikke en funksjon');
        done();
      }
    });
  } else {
    done(new Error('Web server not available'));
  }
});

describe('/answers/new/comment', () => {
  test('create comment (201)', async () => {
    answerServices.newComment = jest.fn(() => Promise.resolve({ status: 201 }));
    const response = await axios.post('/answers/new/comment', {
      answer_id: 1,
      content: 'new content',
    });
    expect(response.status).toBe(201);
  });
  test('error 500', async () => {
    answerServices.newComment = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.post('/answers/new/comment', {
        answer_id: 1,
        content: 'new content',
      });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/answers/update/comment', () => {
  let newComment: A_comment = {
    user_id: 2,
    comment_id: 1,
    username: 'testuser',
    timestamp: '2021-10-10',
    answer_id: 1,
    content: 'new content',
  };
  test('update comment (200)', async () => {
    const response = await axios.put('/answers/update/comment', { comment: newComment });
    expect(response.status).toBe(200);
  });
  test('error 500', async () => {
    answerServices.editComment = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.put('/answers/update/comment', {
        user_id: 2,
        comment_id: 1,
        content: 'new content',
      });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/answers/delete/comment/:comment_id', () => {
  let deleteComment: { user_id: number } = {
    user_id: 2,
  };
  test('delete comment (200)', async () => {
    const response = await axios.delete('/answers/delete/comment/1');
    expect(response.status).toBe(200);
  });

  test('comment not found (404)', async () => {
    answerServices.deleteComment = jest.fn(() => Promise.resolve(null));

    let response;
    try {
      response = await axios.delete('/answers/delete/comment/1796');
    } catch (error: any) {
      response = error.response;
    }
    expect(response.status).toBe(404);
    expect(response.data).toEqual('Comment not found');
  });

  test('error 500', async () => {
    answerServices.deleteComment = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.delete('/answers/delete/comment/1');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/new/comment', () => {
  test('create comment (201)', async () => {
    const response = await axios.post('/questions/new/comment', {
      question_id: 1,
      content: 'new content',
    });
    expect(response.status).toBe(201);
  });

  test('error 500', async () => {
    questionServices.newComment = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.post('/questions/new/comment', {
        question_id: 1,
        content: 'new content',
      });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/update/comments', () => {
  let updateComment: Q_comment = {
    user_id: 2,
    comment_id: 1,
    username: 'testuser',
    timestamp: '2021-10-10',
    question_id: 1,
    content: 'new content',
  };
  test('update comment (200)', async () => {
    const response = await axios.put('/questions/update/comments', { comment: updateComment });
    expect(response.status).toBe(200);
  });

  test('error 500', async () => {
    questionServices.editComment = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.put('/questions/update/comments', {
        comment_id: 1,
        content: 'new content',
      });
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});

describe('/questions/delete/comment/:comment_id', () => {
  test('delete comment (200)', async () => {
    const response = await axios.delete('/questions/delete/comment/7');
    expect(response.status).toBe(200);
  });
  test('comment not found (404)', async () => {
    questionServices.deleteComment = jest.fn(() => Promise.resolve(null));

    let response;
    try {
      response = await axios.delete('/questions/delete/comment/1796');
    } catch (error: any) {
      response = error.response;
    }
    expect(response.status).toBe(404);
    expect(response.data).toEqual('Comment not found');
  });

  test('error 500', async () => {
    questionServices.deleteComment = jest.fn(() => Promise.reject({ status: 500 }));
    try {
      const response = await axios.delete('/questions/delete/comment/1');
    } catch (error: any) {
      expect(error.response.status).toEqual(500);
    }
  });
});
