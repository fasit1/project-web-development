import axios from 'axios';
import pool from '../src/mysql-pool';
import webServer from '../src/server';
import query from './reset_db';

process.env.NODE_ENV = 'test';

jest.spyOn(console, 'info').mockImplementation((text) => {}); //avoids unnecessary console output

axios.defaults.baseURL = `http://localhost:${process.env.PORT}/api/v1`;

beforeAll(async () => {
  // Execute database query
  await new Promise((resolve, reject) => {
    pool.query(query, (error, results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });

  // Wait for the web server to start
  if (!webServer.listening) {
    await new Promise((resolve) => webServer.on('listening', resolve));
  }
});

beforeEach(() => {
  jest.clearAllMocks();
});

afterAll((done) => {
  if (webServer) {
    webServer.close(() => {
      if (pool.end && typeof pool.end === 'function') {
        pool.end((error) => {
          if (error) {
            console.error('Feil under lukking av webserver:', error);
            return done(error);
          }
          done();
        });
      } else {
        console.error('Pool har ingen end-metode eller er ikke en funksjon');
        done();
      }
    });
  } else {
    done(new Error('Web server not available'));
  }
});

describe('teste 401', () => {
  test('tags/favorites/:tag', async () => {
    try {
      await axios.delete('/tags/favorites/someTag', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
      expect(error.response.data).toBe('No user for request');
    }
  });
  test('tags/favorites', async () => {
    try {
      await axios.get('/tags/favorites', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
      expect(error.response.data).toBe('No user for request');
    }
  });
  test('questions/delete/comment/:comment_id', async () => {
    try {
      await axios.delete('/questions/delete/comment/1', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
      expect(error.response.data).toBe('No user for request');
    }
  });
  test('questions/update/comments', async () => {
    try {
      await axios.put('/questions/update/comments', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
      expect(error.response.data).toBe('No user for request');
    }
  });
  test('answers/delete/comment/:comment_id', async () => {
    try {
      await axios.delete('/answers/delete/comment/1', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
      expect(error.response.data).toBe('No user for request');
    }
  });
  test('answers/update/comment', async () => {
    try {
      await axios.put('/answers/update/comment', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
      expect(error.response.data).toBe('No user for request');
    }
  });
  test('answers/new/comment', async () => {
    try {
      await axios.post('/answers/new/comment', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
      expect(error.response.data).toBe('No user for request');
    }
  });
  test('answers/downvote/:answer_id', async () => {
    try {
      await axios.put('/answers/downvote/1', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
      expect(error.response.data).toBe('No user for request');
    }
  });
  test('answers/delete/answer/:answer_id', async () => {
    try {
      await axios.delete('/answers/delete/answer/1', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
      expect(error.response.data).toBe('No user for request');
    }
  });
  test('answers/update/answer', async () => {
    try {
      await axios.put('/answers/update/answer', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
  test('answers/new/answer', async () => {
    try {
      await axios.post('/answers/new/answer', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
  test('questions/unsave/:question_id', async () => {
    try {
      await axios.delete('/questions/unsave/1', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
  test('questions/save', async () => {
    try {
      await axios.post('/questions/save', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
  test('questions/update/answers/best/unselect', async () => {
    try {
      await axios.put('/questions/update/answers/best/unselect', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
  test('questions/update/answers/best', async () => {
    try {
      await axios.put('/questions/update/answers/best', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
  test('questions/downvote/:question_id', async () => {
    try {
      await axios.put('/questions/downvote/1', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
  test('question/upvote/:question_id', async () => {
    try {
      await axios.put('/questions/upvote/1', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
  test('questions/delete/question/:question_id', async () => {
    try {
      await axios.delete('/questions/delete/question/1', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
  test('questions/update/question', async () => {
    try {
      await axios.put('/questions/update/question', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
  test('questions/new/question', async () => {
    try {
      await axios.post('/questions/new/question', {});
      throw new Error('Expected to throw for unauthorized access');
    } catch (error: any) {
      expect(error.response.status).toBe(401);
    }
  });
});
