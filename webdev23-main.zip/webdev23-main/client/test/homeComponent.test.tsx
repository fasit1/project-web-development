import * as React from 'react';
import { shallow } from 'enzyme';
import { Button, Form, Alert } from '../src/components/widgets';
import { Tag, TagWithAmount } from '../src/components/customTypes';
import { Home } from '../src/components/homeComponent';

jest.spyOn(Alert, 'danger').mockImplementation((text) => {});

jest.mock('../src/services/tagServices', () => {
  class TagServices {
    getFavorites() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
      ]);
    }
    getPopular() {
      return Promise.resolve([
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
    getAll() {
      return Promise.resolve<TagWithAmount[]>([
        { content: 'a-tag', question_amount: 1 },
        { content: 'b-tag', question_amount: 3 },
        { content: 'tag1', question_amount: 2 },
        { content: 'tag3', question_amount: 2 },
      ]);
    }

    removeFromFavorites() {
      return Promise.resolve();
    }

    addToFavorites() {
      return Promise.resolve();
    }
  }
  return new TagServices();
});

jest.mock('../src/services/userServices', () => {
  class UserService {
    getUser() {
      return Promise.resolve({
        user_id: 1,
        username: 'user1',
        email: 'user@user.no',
        picture: 'url.com',
      });
    }

    authenticateUser() {
      return Promise.resolve(true);
    }

    getAllUsers() {
      return Promise.resolve([
        {
          user_id: 1,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 2,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 3,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
      ]);
    }
    create(username: string, password: string, email: string, firstName: string, lastName: string) {
      return Promise.resolve();
    }

    login(username: string, password: string) {
      return Promise.resolve();
    }
  }

  return new UserService();
});

jest.mock('../src/services/questionServices', () => {
  class QuestionsServices {
    getQuestion() {
      return Promise.resolve({
        question_id: 1,
        title: 'title1',
        content: 'content1',
        timestamp: new Date(1),
        answered: false,
        user_id: 1,
        username: 'user1',
        upvotes: 10,
        answers: [],
        tags: [{ content: 'tag1' }],
        comments: [],
        voted_by_user: 0,
      });
    }

    upvote(question_id: number) {
      return Promise.resolve();
    }

    downvote(question_id: number) {
      return Promise.resolve();
    }

    getAllQuestions(questionsType: string, answered: boolean | undefined) {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: ['tag1'],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: ['tag2'],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: ['tag3'],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    getEveryQuestion() {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag1' }],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag2' }],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag3' }],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    createQuestion(title: string, content: string, tags: Tag[]) {
      return Promise.resolve();
    }

    getQuestionsByTag(tag: string, questionsType: string, answered: boolean | undefined) {
      return Promise.resolve([
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: ['tag3'],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
  }

  return new QuestionsServices();
});

describe('Home page tests', () => {
  afterEach(() => {
    jest.spyOn(Alert, 'danger').mockClear();
    jest.spyOn(console, 'error').mockClear();
  });

  test('Home page draws correctly after mount', async () => {
    const wrapper = shallow(<Home />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });

  test('Home page filter buttons works correctly', async () => {
    location.hash = '#/tags/tag2';
    const wrapper = shallow(<Home />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const recent = wrapper.find('div').at(3);
    recent.simulate('click');

    expect((wrapper.instance() as Home).questionsType).toBe('recent');

    const popular = wrapper.find('div').at(2);
    popular.simulate('click');

    expect((wrapper.instance() as Home).questionsType).toBe('popular');
  });

  test('Home page select changes value correctly', async () => {
    location.hash = '#/tags/tag1';
    const wrapper = shallow(<Home />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    const select = wrapper.find(Form.Select).at(0);
    select.simulate('change', { target: { value: 'answered' } });
    expect((wrapper.instance() as Home).answered_select).toBe('answered');
  });

  test('username, question ans tags links correctly', async () => {
    const wrapper = shallow(<Home />);
    location.hash = '/questions';
    await new Promise((resolve) => setTimeout(resolve, 0));

    const username = wrapper.find('span').at(0);
    username.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe(`#/profile/user1`);

    location.hash = '/tags/tag2';
    await new Promise((resolve) => setTimeout(resolve, 0));

    const question = wrapper.find('h5').at(0);
    question.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe(`#/questions/1`);

    location.hash = '/tags/tag2';
    await new Promise((resolve) => setTimeout(resolve, 0));

    const tag1 = wrapper.find('span').at(2);
    tag1.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe(`#/tags/tag1`);
  });
  test('upvote Button calls upvoteButton()  and downvote Button calls downvoteButton() correctly', async () => {
    const wrapper = shallow(<Home />);
    location.hash = '#/tags/tag2';
    await new Promise((resolve) => setTimeout(resolve, 0));
    const upvoteButtonFunc = jest.spyOn(wrapper.instance() as Home, 'upvoteButton');
    const upvoteButton = wrapper.find('p').at(1);
    upvoteButton.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(upvoteButtonFunc).toHaveBeenCalled();
    upvoteButtonFunc.mockRestore();

    const downvoteButtonFunc = jest.spyOn(wrapper.instance() as Home, 'downvoteButton');
    const downvoteButton = wrapper.find('p').at(3);
    downvoteButton.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(downvoteButtonFunc).toHaveBeenCalled();
    downvoteButtonFunc.mockRestore();
  });

  test('Home page draws correctly with tags after mount', async () => {
    const wrapper = shallow(<Home />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/tags/tag2';

    const tag1 = wrapper.find('span').at(2);
    tag1.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(wrapper).toMatchSnapshot();
  });

  test('Home page add to and remove from favorites buttons works correctly', async () => {
    const wrapper = shallow(<Home />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    const addFavFunc = jest.spyOn(wrapper.instance() as Home, 'addToFavoritesButton');
    const addFav = wrapper.find(Button.Light).at(0);
    addFav.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(addFavFunc).toHaveBeenCalled();
    addFavFunc.mockRestore();
  });
});
