import * as React from 'react';
import { shallow } from 'enzyme';
import { Button, Form, Alert } from '../src/components/widgets';
import { Tag, User } from '../src/components/customTypes';
import { Profile } from '../src/components/profileComponent';

jest.spyOn(Alert, 'danger').mockImplementation((text) => {});
jest.spyOn(console, 'error').mockImplementation((text) => {});

jest.mock('../src/services/tagServices', () => {
  class TagServices {
    getFavorites() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
      ]);
    }
    getPopular() {
      return Promise.resolve([
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
    getAll() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
  }
  return new TagServices();
});

jest.mock('../src/services/userServices', () => {
  class UserService {
    getUser() {
      return Promise.resolve({
        user_id: 1,
        username: 'user1',
        email: 'user@user.no',
        picture: 'url.com',
      });
    }

    authenticateUser() {
      return Promise.resolve(true);
    }

    getAllUsers() {
      return Promise.resolve([
        {
          user_id: 1,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 2,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 3,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
      ]);
    }
    create(username: string, password: string, email: string, firstName: string, lastName: string) {
      return Promise.resolve();
    }

    login(username: string, password: string) {
      return Promise.resolve();
    }

    getUserByUsername(username: string) {
      return Promise.resolve({
        user_id: 1,
        username: 'user1',
        email: 'user@user.no',
        picture: 'url.com',
      });
    }

    logOut() {
      return Promise.resolve();
    }
    getContent(user_id: number) {
      return Promise.resolve({
        a_comments: [
          {
            answer_id: 7,
            comment_id: 14,
            content: 'hei',
            question_id: 4,
            timestamp: '2023-11-17T18:34:20.000Z',
            title: 'Frontend Frameworks Comparison',
            user_id: 18,
          },
        ],
        answers: [
          {
            answer_id: 13,
            best_answer: false,
            content: 'dette skal være nytt med ingen upvotes',
            question_id: 11,
            timestamp: '2023-11-16T14:22:47.000Z',
            title: 'test',
            upvotes: 0,
            user_id: 18,
          },
        ],
        q_comments: [
          {
            comment_id: 7,
            content: 'a',
            question_id: 11,
            timestamp: '2023-11-16T14:32:45.000Z',
            title: 'test',
            user_id: 18,
          },
        ],
        questions: [
          {
            answer_count: 0,
            answered: false,
            content: 'What is a node 2',
            question_id: 22,
            timestamp: '2022-11-17T18:35:22.000Z',
            title: 'What is a node',
            upvotes: 1,
            user_id: 18,
          },
          {
            answer_count: 0,
            answered: false,
            content: 'What is a node 3 ',
            question_id: 23,
            timestamp: '2023-11-17T18:35:22.000Z',
            title: 'What is a node3',
            upvotes: 2,
            user_id: 18,
          },
          {
            answer_count: 0,
            answered: false,
            content: 'What is a node',
            question_id: 1,
            timestamp: '2021-11-17T18:35:22.000Z',
            title: 'What is a node',
            upvotes: 2,
            user_id: 18,
          },
        ],
        stats: [
          {
            answers: 5,
            comments: 4,
            points: 4,
            questions: 2,
            title: 'Experienced User',
            xp: 724,
          },
        ],
      });
    }

    updateUser(user: User) {
      return Promise.resolve();
    }

    deleteUser(user_id: number) {
      return Promise.resolve();
    }
  }

  return new UserService();
});

jest.mock('../src/services/questionServices', () => {
  class QuestionsServices {
    getQuestion() {
      return Promise.resolve({
        question_id: 1,
        title: 'title1',
        content: 'content1',
        timestamp: new Date(1),
        answered: false,
        user_id: 1,
        username: 'user1',
        upvotes: 10,
        answers: [],
        tags: { content: 'tag1' },
        comments: [],
        voted_by_user: 0,
      });
    }

    getEveryQuestion() {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag1' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag2' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag3' },
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    createQuestion(title: string, content: string, tags: Tag[]) {
      return Promise.resolve();
    }

    getSavedQuestions() {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag1' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag2' },
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
  }

  return new QuestionsServices();
});

describe('Profile tests', () => {
  afterEach(() => {
    jest.spyOn(Alert, 'danger').mockClear();
    jest.spyOn(console, 'error').mockClear();
  });

  test('Profile draws correctly after mount', async () => {
    const wrapper = shallow(<Profile match={{ params: { username: 'User1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });

  test('custom buttons set activeButton to correct value', async () => {
    const wrapper = shallow(<Profile match={{ params: { username: 'User1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/profile/user1';

    const profileButton = wrapper.find('span').at(0);
    profileButton.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as Profile).activeButton).toBe('profile');

    const savedButton = wrapper.find('span').at(1);
    savedButton.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as Profile).activeButton).toBe('saved');

    const settingsButton = wrapper.find('span').at(2);
    settingsButton.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as Profile).activeButton).toBe('settings');

    const logOutButton = wrapper.find('span').at(3);
    logOutButton.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe('#/questions');
  });

  test('content p links correctly', async () => {
    const wrapper = shallow(<Profile match={{ params: { username: 'User1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/profile/user1';

    const question = wrapper.find('p').at(0);
    question.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(
      `#/questions/${(wrapper.instance() as Profile).content.questions[0].question_id}`,
    );

    location.hash = '#/profile/user1';
    const answer = wrapper.find('p').at(3);
    answer.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(
      `#/questions/${(wrapper.instance() as Profile).content.answers[0].question_id}`,
    );

    location.hash = '#/profile/user1';
    const q_comment = wrapper.find('p').at(4);
    q_comment.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(
      `#/questions/${(wrapper.instance() as Profile).content.q_comments[0].question_id}`,
    );

    location.hash = '#/profile/user1';
    const a_comment = wrapper.find('p').at(5);
    a_comment.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(
      `#/questions/${(wrapper.instance() as Profile).content.a_comments[0].question_id}`,
    );
  });

  test('saved p links correctly', async () => {
    const wrapper = shallow(<Profile match={{ params: { username: 'User1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/profile/user1';
    (wrapper.instance() as Profile).activeButton = 'saved';
    const question = wrapper.find('p').at(0);
    question.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(
      `#/questions/${(wrapper.instance() as Profile).savedQuestions[0].question_id}`,
    );
  });

  test('settings inputs work correctly', async () => {
    const wrapper = shallow(<Profile match={{ params: { username: 'User1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/profile/user1';
    const settingsButton = wrapper.find('span').at(2);
    settingsButton.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as Profile).activeButton).toBe('settings');

    const username = wrapper.find(Form.Input).at(0);
    username.simulate('change', { currentTarget: { value: 'test1' } });

    expect((wrapper.instance() as Profile).newUsername).toBe('test1');

    const email = wrapper.find(Form.Input).at(1);
    email.simulate('change', { currentTarget: { value: 'test2' } });

    expect((wrapper.instance() as Profile).newEmail).toBe('test2');

    const pfp = wrapper.find(Form.Input).at(2);
    pfp.simulate('change', { currentTarget: { value: 'test3.jpg' } });

    expect((wrapper.instance() as Profile).newPFP).toBe('test3.jpg');

    const aboutMe = wrapper.find(Form.Textarea).at(0);
    aboutMe.simulate('change', { currentTarget: { value: 'test4' } });

    expect((wrapper.instance() as Profile).newAboutMe).toBe('test4');

    const button = wrapper.find(Button.Success).at(0);
    button.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as Profile).activeButton).toBe('profile');
  });

  test('saveButton() works correctly', async () => {
    const wrapper = shallow(<Profile match={{ params: { username: 'User1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const user = (wrapper.instance() as Profile).user ? (wrapper.instance() as Profile).user : null;
    (wrapper.instance() as Profile).newUsername = '';
    if (user) (wrapper.instance() as Profile).saveButton(user);
    expect(Alert.danger).toHaveBeenCalledWith('Error updating user data: Username format wrong');

    (wrapper.instance() as Profile).newUsername = 'username';
    (wrapper.instance() as Profile).newEmail = '';
    if (user) (wrapper.instance() as Profile).saveButton(user);
    expect(Alert.danger).toHaveBeenCalledWith('Error updating user data: Email format wrong');

    (wrapper.instance() as Profile).newUsername = 'username';
    (wrapper.instance() as Profile).newEmail = 'email@email.com';
    (wrapper.instance() as Profile).newPFP = 'wrong';
    if (user) (wrapper.instance() as Profile).saveButton(user);
    expect(Alert.danger).toHaveBeenCalledWith('Error updating user data: Invalid image URL');

    (wrapper.instance() as Profile).newUsername = 'username';
    (wrapper.instance() as Profile).newEmail = 'email@email.com';
    (wrapper.instance() as Profile).newPFP = '';
    if (user) (wrapper.instance() as Profile).saveButton(user);
    expect((wrapper.instance() as Profile).user?.picture).toBe(
      'https://livileire.no/wp-content/uploads/2022/03/Portrait_Placeholder.jpg',
    );

    (wrapper.instance() as Profile).newUsername = 'username';
    (wrapper.instance() as Profile).newEmail = 'email@email.com';
    (wrapper.instance() as Profile).newPFP = 'wrong.jpg';

    for (let i = 0; (wrapper.instance() as Profile).newAboutMe.length <= 550; i++) {
      (wrapper.instance() as Profile).newAboutMe += 'This is a long about me. ';
    }
    if (user) (wrapper.instance() as Profile).saveButton(user);
    expect(Alert.danger).toHaveBeenCalledWith(
      'Error updating user data: About Me section cannot exceed 500 characters',
    );
  });

  test('delete user works correctly', async () => {
    const wrapper = shallow(<Profile match={{ params: { username: 'User1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    (wrapper.instance() as Profile).activeButton = 'settings';
    await new Promise((resolve) => setTimeout(resolve, 0));

    const delete_button = wrapper.find(Button.Danger).at(0);
    delete_button.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as Profile).deleteUserToggle).toBe(true);

    const decline_button = wrapper.find(Button.Light).at(0);
    decline_button.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as Profile).deleteUserToggle).toBe(false);

    (wrapper.instance() as Profile).deleteUserToggle = true;

    const accept_button = wrapper.find(Button.Danger).at(0);
    accept_button.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(`#/questions`);
  });

  test('sort() works correctly', async () => {
    const wrapper = shallow(<Profile match={{ params: { username: 'User1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as Profile).content.questions).toStrictEqual([
      {
        answer_count: 0,
        answered: false,
        content: 'What is a node 3 ',
        question_id: 23,
        timestamp: '2023-11-17T18:35:22.000Z',
        title: 'What is a node3',
        upvotes: 2,
        user_id: 18,
      },
      {
        answer_count: 0,
        answered: false,
        content: 'What is a node 2',
        question_id: 22,
        timestamp: '2022-11-17T18:35:22.000Z',
        title: 'What is a node',
        upvotes: 1,
        user_id: 18,
      },
      {
        answer_count: 0,
        answered: false,
        content: 'What is a node',
        question_id: 1,
        timestamp: '2021-11-17T18:35:22.000Z',
        title: 'What is a node',
        upvotes: 2,
        user_id: 18,
      },
    ]);
  });
});
