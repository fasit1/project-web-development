import * as React from 'react';
import {
  Alert,
  Button,
  Card,
  Column,
  Row,
  Form,
  upArrow,
  downArrow,
  plusSVG,
  minusSVG,
} from '../src/components/widgets';
import { shallow } from 'enzyme';

describe('Widget drawing tests', () => {
  test('Card draws correctly', () => {
    const wrapper = shallow(<Card title={'test'}></Card>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Card draws correctly with style', () => {
    const wrapper = shallow(<Card title={'test'} style={{ width: '200px' }}></Card>);
    expect(wrapper).toMatchSnapshot();
  });

  test('Row draws correctly', () => {
    const wrapper = shallow(<Row></Row>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Row draws correctly width max width', () => {
    const wrapper = shallow(<Row max_width></Row>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Column draws correctly right', () => {
    const wrapper = shallow(<Column width={10} right></Column>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Column draws correctly left', () => {
    const wrapper = shallow(<Column></Column>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Column draws correctly with style', () => {
    const wrapper = shallow(<Column className="noe"></Column>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Column draws correctly with matchparent', () => {
    const wrapper = shallow(<Column matchParent></Column>);
    expect(wrapper).toMatchSnapshot();
  });

  test('Button.Success draws correctly', () => {
    const wrapper = shallow(<Button.Success onClick={() => {}}></Button.Success>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Button.Danger draws correctly', () => {
    const wrapper = shallow(<Button.Danger onClick={() => {}}></Button.Danger>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Button.Light draws correctly', () => {
    const wrapper = shallow(<Button.Light onClick={() => {}}></Button.Light>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Small Button.Success draws correctly', () => {
    const wrapper = shallow(<Button.Success onClick={() => {}} small></Button.Success>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Small Button.Danger draws correctly', () => {
    const wrapper = shallow(<Button.Danger onClick={() => {}} small></Button.Danger>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Small Button.Light draws correctly', () => {
    const wrapper = shallow(<Button.Light onClick={() => {}} small></Button.Light>);
    expect(wrapper).toMatchSnapshot();
  });

  test('Form.Label draws correctly', () => {
    const wrapper = shallow(<Form.Label>Noe</Form.Label>);
    expect(wrapper).toMatchSnapshot();
  });
  test('Form.Input draws correctly', () => {
    const wrapper = shallow(
      <Form.Input type="string" value={'noe'} onChange={() => {}}></Form.Input>,
    );
    expect(wrapper).toMatchSnapshot();
  });
  test('Form.Input draws correctly width width', () => {
    const wrapper = shallow(
      <Form.Input type="string" value={'noe'} onChange={() => {}} width={'100px'}></Form.Input>,
    );
    expect(wrapper).toMatchSnapshot();
  });
  test('Form.Textarea draws correctly', () => {
    const wrapper = shallow(
      <Form.Textarea type="string" value={'noe'} onChange={() => {}}></Form.Textarea>,
    );
    expect(wrapper).toMatchSnapshot();
  });

  test('Form.Select draws correctly', () => {
    const wrapper = shallow(<Form.Select value={'noe'} onChange={() => {}}></Form.Select>);
    expect(wrapper).toMatchSnapshot();
  });
});

describe('Alert tests', () => {
  test('No alerts initially', () => {
    const wrapper = shallow(<Alert />);

    expect(wrapper.matchesElement(<div></div>)).toEqual(true);
  });

  test('Show alert danger message', (done) => {
    const wrapper = shallow(<Alert />);

    Alert.danger('test');

    // Wait for events to complete
    setTimeout(() => {
      expect(
        wrapper.matchesElement(
          <div>
            <div>
              test
              <button />
            </div>
          </div>,
        ),
      ).toEqual(true);

      done();
    });
  });

  test('Show alert success message', (done) => {
    const wrapper = shallow(<Alert />);

    Alert.success('test');

    // Wait for events to complete
    setTimeout(() => {
      expect(
        wrapper.matchesElement(
          <div>
            <div>
              test
              <button />
            </div>
          </div>,
        ),
      ).toEqual(true);

      done();
    });
  });

  test('Show alert info message', (done) => {
    const wrapper = shallow(<Alert />);

    Alert.info('test');

    // Wait for events to complete
    setTimeout(() => {
      expect(
        wrapper.matchesElement(
          <div>
            <div>
              test
              <button />
            </div>
          </div>,
        ),
      ).toEqual(true);

      done();
    });
  });

  test('Show alert warning message', (done) => {
    const wrapper = shallow(<Alert />);

    Alert.warning('test');

    // Wait for events to complete
    setTimeout(() => {
      expect(
        wrapper.matchesElement(
          <div>
            <div>
              test
              <button />
            </div>
          </div>,
        ),
      ).toEqual(true);

      done();
    });
  });

  test('Close alert danger message', (done) => {
    const wrapper = shallow(<Alert />);

    Alert.danger('test');

    // Wait for events to complete
    setTimeout(() => {
      expect(
        wrapper.matchesElement(
          <div>
            <div>
              test
              <button />
            </div>
          </div>,
        ),
      ).toEqual(true);

      wrapper.find('button.btn-close').simulate('click');

      expect(wrapper.matchesElement(<div></div>)).toEqual(true);

      done();
    });
  });

  test('Close alert success message', (done) => {
    const wrapper = shallow(<Alert />);

    Alert.success('test');

    // Wait for events to complete
    setTimeout(() => {
      expect(
        wrapper.matchesElement(
          <div>
            <div>
              test
              <button />
            </div>
          </div>,
        ),
      ).toEqual(true);

      wrapper.find('button.btn-close').simulate('click');

      expect(wrapper.matchesElement(<div></div>)).toEqual(true);

      done();
    });
  });
  test('Close alert info message', (done) => {
    const wrapper = shallow(<Alert />);

    Alert.info('test');

    // Wait for events to complete
    setTimeout(() => {
      expect(
        wrapper.matchesElement(
          <div>
            <div>
              test
              <button />
            </div>
          </div>,
        ),
      ).toEqual(true);

      wrapper.find('button.btn-close').simulate('click');

      expect(wrapper.matchesElement(<div></div>)).toEqual(true);

      done();
    });
  });
  test('Close alert warning message', (done) => {
    const wrapper = shallow(<Alert />);

    Alert.warning('test');

    // Wait for events to complete
    setTimeout(() => {
      expect(
        wrapper.matchesElement(
          <div>
            <div>
              test
              <button />
            </div>
          </div>,
        ),
      ).toEqual(true);

      wrapper.find('button.btn-close').simulate('click');

      expect(wrapper.matchesElement(<div></div>)).toEqual(true);

      done();
    });
  });
});

describe('Svg symbols tests', () => {
  test('upArrow draws correctly', () => {
    const wrapper = shallow(upArrow('grey'));
    expect(wrapper).toMatchSnapshot();
  });
  test('downArrow draws correctly', () => {
    const wrapper = shallow(downArrow('grey'));
    expect(wrapper).toMatchSnapshot();
  });
  test('plusSvg draws correctly', () => {
    const wrapper = shallow(plusSVG);
    expect(wrapper).toMatchSnapshot();
  });
  test('minusSvg draws correctly', () => {
    const wrapper = shallow(minusSVG);
    expect(wrapper).toMatchSnapshot();
  });
});
