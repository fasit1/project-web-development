import * as React from 'react';
import { shallow } from 'enzyme';
import { Button, Alert } from '../src/components/widgets';
import { Answer, Q_comment, Question, Tag, TagWithAmount } from '../src/components/customTypes';
import { QuestionsInspect } from '../src/components/questionInspectComponent';

jest.spyOn(Alert, 'danger').mockImplementation((text) => {});

jest.mock('../src/services/tagServices', () => {
  class TagServices {
    getFavorites() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
      ]);
    }
    getPopular() {
      return Promise.resolve([
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
    getAll() {
      return Promise.resolve<TagWithAmount[]>([
        { content: 'a-tag', question_amount: 1 },
        { content: 'b-tag', question_amount: 3 },
        { content: 'c-tag', question_amount: 2 },
      ]);
    }

    removeFromFavorites() {
      return Promise.resolve();
    }

    addToFavorites() {
      return Promise.resolve();
    }
  }
  return new TagServices();
});

jest.mock('../src/services/userServices', () => {
  class UserService {
    getUser() {
      return Promise.resolve({
        user_id: 1,
        username: 'user1',
        email: 'user@user.no',
        picture: 'url.com',
      });
    }

    authenticateUser() {
      return Promise.resolve(true);
    }

    getAllUsers() {
      return Promise.resolve([
        {
          user_id: 1,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 2,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 3,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
      ]);
    }
    create(username: string, password: string, email: string, firstName: string, lastName: string) {
      return Promise.resolve();
    }

    login(username: string, password: string) {
      return Promise.resolve();
    }
  }

  return new UserService();
});

jest.mock('../src/services/questionServices', () => {
  class QuestionsServices {
    getQuestion() {
      return Promise.resolve({
        question_id: 1,
        title: 'title1',
        content: 'content1',
        timestamp: new Date(1),
        answered: false,
        user_id: 1,
        username: 'user1',
        upvotes: 10,
        answers: [
          {
            answer_id: 26,
            best_answer: true,
            comments: [
              {
                answer_id: 26,
                comment_id: 15,
                content: 'a',
                fullname: 'test test',
                timestamp: '2023-11-19T11:41:46.000Z',
                user_id: 1,
                username: 'user1',
              },
            ],
            content: 'a',
            fullname: 'test test',
            question_id: 27,
            timestamp: '2023-11-18T15:55:21.000Z',
            upvotes: 0,
            user_id: 1,
            username: 'user1',
            voted_by_user: 2,
          },
        ],
        tags: [{ content: 'tag1' }],
        comments: [
          {
            comment_id: 11,
            content: 'halla',
            fullname: 'test test',
            question_id: 27,
            timestamp: '2023-11-19T11:41:42.000Z',
            user_id: 1,
            username: 'user1',
          },
        ],
        voted_by_user: 0,
      });
    }

    deleteQuestion(question_id: number) {
      return Promise.resolve();
    }

    deleteComment(comment_id: number) {
      return Promise.resolve();
    }
    upvote(question_id: number) {
      return Promise.resolve();
    }

    downvote(question_id: number) {
      return Promise.resolve();
    }
    update(qustion: Question) {
      return Promise.resolve();
    }

    editComment(comment: Comment) {
      return Promise.resolve();
    }

    getAllQuestions(questionsType: string, answered: boolean | undefined) {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: ['tag1'],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: ['tag2'],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: ['tag3'],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    getEveryQuestion() {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag1' }],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag2' }],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag3' }],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }

    selectBestAnswer(answer: Answer) {
      return Promise.resolve();
    }

    unselectBestAnswer(answer: Answer) {
      return Promise.resolve();
    }
    createQuestion(title: string, content: string, tags: Tag[]) {
      return Promise.resolve();
    }

    saveQuestion(questions: Question) {
      return Promise.resolve();
    }

    unsaveQuestion(questions: Question) {
      return Promise.resolve();
    }
    getSavedQuestions() {
      return Promise.resolve([
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag3' }],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    getQuestionsByTag(tag: string, questionsType: string, answered: boolean | undefined) {
      return Promise.resolve([
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: ['tag3'],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
  }

  return new QuestionsServices();
});

jest.mock('../src/services/answerServices', () => {
  class AnswerServcie {
    upvote(question_id: number) {
      return Promise.resolve();
    }

    downvote(question_id: number) {
      return Promise.resolve();
    }

    update(answer: Answer) {
      return Promise.resolve();
    }

    deleteAnswer(answer_id: number) {
      return Promise.resolve();
    }

    deleteComment(comment_id: number) {
      return Promise.resolve();
    }

    editComment(comment_id: number) {
      return Promise.resolve();
    }
  }

  return new AnswerServcie();
});

describe('Home page tests', () => {
  afterEach(() => {
    jest.spyOn(Alert, 'danger').mockClear();
    jest.spyOn(console, 'error').mockClear();
  });

  test('Home page draws correctly after mount', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });

  test('upvote Button calls upvoteQuestionButton() and downvote Button calls downvoteQuestionButton() on question correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    const upvoteButtonFunc = jest.spyOn(
      wrapper.instance() as QuestionsInspect,
      'upvoteQuestionButton',
    );
    const upvoteButton = wrapper.find('p').at(0);
    upvoteButton.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(upvoteButtonFunc).toHaveBeenCalled();
    upvoteButtonFunc.mockRestore();

    const downvoteButtonFunc = jest.spyOn(
      wrapper.instance() as QuestionsInspect,
      'downvoteQuestionButton',
    );
    const downvoteButton = wrapper.find('p').at(2);
    downvoteButton.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(downvoteButtonFunc).toHaveBeenCalled();
    downvoteButtonFunc.mockRestore();
  });

  test('username on question and c_question links correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/questions/1';
    const q_username = wrapper.find('span').at(0);
    q_username.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(`#/profile/user1`);
    location.hash = '#/questions/1';
    const c_username = wrapper.find('span').at(5);
    c_username.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(`#/profile/user1`);
  });

  test('tags on question links correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/questions/1';

    const tag = wrapper.find('span').at(4);
    tag.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(`#/tags/tag1`);
  });

  test('comment and answer on question works correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const comment = wrapper.find(Button.Light).at(0);
    comment.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as QuestionsInspect).input.type).toBe('Comment');

    const answer = wrapper.find(Button.Light).at(1);
    answer.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as QuestionsInspect).input.type).toBe('Answer');
  });

  test('Ellipsis toggles and ellipsis buttons works correctly on question and q_comment', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const q_ellipsis = wrapper.find('span').at(2);
    q_ellipsis.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as QuestionsInspect).toggle_question_ellipsis).toBe(false);

    const q_edit = wrapper.find(Button.Light).at(0);
    q_edit.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as QuestionsInspect).input.update_toggle).toBe(true);
    (wrapper.instance() as QuestionsInspect).input.update_toggle = false;

    const q_deleteButtonFunc = jest.spyOn(wrapper.instance() as QuestionsInspect, 'deletePost');
    const q_delete = wrapper.find(Button.Danger).at(0);
    q_delete.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(q_deleteButtonFunc).toHaveBeenCalled();
    q_deleteButtonFunc.mockRestore();
    (wrapper.instance() as QuestionsInspect).toggle_question_ellipsis = true;
  });

  test('Ellipsis toggles and ellipsis buttons works correctly on q_comment', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const c_ellipsis = wrapper.find('span').at(7);
    c_ellipsis.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as QuestionsInspect).toggle_c_question_ellipsis[11]).toBe(false);

    const c_edit = wrapper.find(Button.Light).at(2);
    c_edit.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as QuestionsInspect).input.update_toggle).toBe(true);
    (wrapper.instance() as QuestionsInspect).input.update_toggle = false;

    const c_deleteButtonFunc = jest.spyOn(wrapper.instance() as QuestionsInspect, 'deleteQComment');
    const c_delete = wrapper.find(Button.Danger).at(0);
    c_delete.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(c_deleteButtonFunc).toHaveBeenCalled();
    c_deleteButtonFunc.mockRestore();
    (wrapper.instance() as QuestionsInspect).toggle_question_ellipsis = true;
  });

  test('sorting changes values correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const popular = wrapper.find('div').at(5);
    popular.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as QuestionsInspect).answerType).toBe('popular');

    const recent = wrapper.find('div').at(4);
    recent.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as QuestionsInspect).answerType).toBe('recent');
  });

  test('upvote Button calls upvoteAnswerButton() and downvote Button calls downvoteAnswerButton() on answer correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    const upvoteButtonFunc = jest.spyOn(
      wrapper.instance() as QuestionsInspect,
      'upvoteAnswerButton',
    );
    const upvoteButton = wrapper.find('p').at(5);
    upvoteButton.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(upvoteButtonFunc).toHaveBeenCalled();
    upvoteButtonFunc.mockRestore();

    const downvoteButtonFunc = jest.spyOn(
      wrapper.instance() as QuestionsInspect,
      'downvoteAnswerButton',
    );
    const downvoteButton = wrapper.find('p').at(7);
    downvoteButton.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(downvoteButtonFunc).toHaveBeenCalled();
    downvoteButtonFunc.mockRestore();
  });

  test('username on answer and a_comment links correctly', async () => {
    location.hash = '#/questions/1';
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    const q_username = wrapper.find('span').at(10);
    q_username.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(`#/profile/user1`);

    location.hash = '#/questions/1';
    await new Promise((resolve) => setTimeout(resolve, 0));
    const a_username = wrapper.find('span').at(15);
    a_username.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(location.hash).toBe(`#/profile/user1`);
  });

  test('comment on answer works correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    const comment = wrapper.find(Button.Light).at(2);
    comment.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as QuestionsInspect).input.type).toBe('Comment');
  });

  test('Ellipsis toggles and ellipsis buttons works correctly on question and q_comment', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const a_ellipsis = wrapper.find('span').at(13);
    a_ellipsis.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(
      (wrapper.instance() as QuestionsInspect).toggle_answer_ellipsis[
        (wrapper.instance() as QuestionsInspect).answers[0].answer_id
      ],
    ).toBe(false);

    const a_edit = wrapper.find(Button.Light).at(3);
    a_edit.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as QuestionsInspect).input.update_toggle).toBe(true);
    (wrapper.instance() as QuestionsInspect).input.update_toggle = false;

    const a_deleteButtonFunc = jest.spyOn(wrapper.instance() as QuestionsInspect, 'deletePost');
    const a_delete = wrapper.find(Button.Danger).at(0);
    a_delete.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(a_deleteButtonFunc).toHaveBeenCalled();
    a_deleteButtonFunc.mockRestore();
  });

  test('Ellipsis toggles and ellipsis buttons works correctly on q_comment', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const c_ellipsis = wrapper.find('span').at(17);
    c_ellipsis.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(
      (wrapper.instance() as QuestionsInspect).toggle_c_answer_ellipsis[
        (wrapper.instance() as QuestionsInspect).answers[0].comments[0].comment_id
      ],
    ).toBe(false);

    const c_edit = wrapper.find(Button.Light).at(3);
    c_edit.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as QuestionsInspect).input.update_toggle).toBe(true);
    (wrapper.instance() as QuestionsInspect).input.update_toggle = false;

    const c_deleteButtonFunc = jest.spyOn(wrapper.instance() as QuestionsInspect, 'deleteAComment');
    const c_delete = wrapper.find(Button.Danger).at(0);
    c_delete.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(c_deleteButtonFunc).toHaveBeenCalled();
    c_deleteButtonFunc.mockRestore();
  });

  test('sortAnswers sorst answers correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as QuestionsInspect).answers = [
      {
        answer_id: 26,
        best_answer: true,
        content: 'a',
        question_id: 27,
        comments: [],
        timestamp: '2000-11-18T15:55:21.000Z',
        upvotes: 1,
        user_id: 1,
        username: 'user1',
        voted_by_user: 2,
      },
      {
        answer_id: 26,
        best_answer: false,
        content: 'a',
        question_id: 27,
        timestamp: '2021-11-18T15:55:21.000Z',
        upvotes: 1000,
        comments: [],
        user_id: 1,
        username: 'user1',
        voted_by_user: 2,
      },
      {
        answer_id: 26,
        best_answer: false,
        content: 'a',
        question_id: 27,
        timestamp: '2023-11-18T15:55:21.000Z',
        upvotes: 100,
        comments: [],
        user_id: 1,
        username: 'user1',
        voted_by_user: 2,
      },
    ];

    (wrapper.instance() as QuestionsInspect).answerType = 'recent';
    (wrapper.instance() as QuestionsInspect).sortAnswers();
    expect((wrapper.instance() as QuestionsInspect).answers).toStrictEqual([
      {
        answer_id: 26,
        best_answer: true,
        content: 'a',
        question_id: 27,
        comments: [],
        timestamp: '2000-11-18T15:55:21.000Z',
        upvotes: 1,
        user_id: 1,
        username: 'user1',
        voted_by_user: 2,
      },
      {
        answer_id: 26,
        best_answer: false,
        content: 'a',
        question_id: 27,
        timestamp: '2023-11-18T15:55:21.000Z',
        upvotes: 100,
        comments: [],
        user_id: 1,
        username: 'user1',
        voted_by_user: 2,
      },
      {
        answer_id: 26,
        best_answer: false,
        content: 'a',
        question_id: 27,
        timestamp: '2021-11-18T15:55:21.000Z',
        upvotes: 1000,
        comments: [],
        user_id: 1,
        username: 'user1',
        voted_by_user: 2,
      },
    ]);

    (wrapper.instance() as QuestionsInspect).answerType = 'popular';
    (wrapper.instance() as QuestionsInspect).sortAnswers();

    expect((wrapper.instance() as QuestionsInspect).answers).toStrictEqual([
      {
        answer_id: 26,
        best_answer: true,
        content: 'a',
        question_id: 27,
        comments: [],
        timestamp: '2000-11-18T15:55:21.000Z',
        upvotes: 1,
        user_id: 1,
        username: 'user1',
        voted_by_user: 2,
      },
      {
        answer_id: 26,
        best_answer: false,
        content: 'a',
        question_id: 27,
        timestamp: '2021-11-18T15:55:21.000Z',
        upvotes: 1000,
        comments: [],
        user_id: 1,
        username: 'user1',
        voted_by_user: 2,
      },
      {
        answer_id: 26,
        best_answer: false,
        content: 'a',
        question_id: 27,
        timestamp: '2023-11-18T15:55:21.000Z',
        upvotes: 100,
        comments: [],
        user_id: 1,
        username: 'user1',
        voted_by_user: 2,
      },
    ]);
  });

  test('addReply works  correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as QuestionsInspect).input.type = 'Comment';

    for (let i = 0; (wrapper.instance() as QuestionsInspect).input.content.length <= 500; i++) {
      (wrapper.instance() as QuestionsInspect).input.content += 'This is a long comment . ';
    }
    (wrapper.instance() as QuestionsInspect).addReply();

    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(Alert.danger).toHaveBeenCalledWith(
      'Error creating content: Comment cannot exceed 500 characters',
    );

    (wrapper.instance() as QuestionsInspect).input.content = 'This is ok length  comment . ';

    (wrapper.instance() as QuestionsInspect).addReply();
    expect((wrapper.instance() as QuestionsInspect).input.toggle).toBe(false);
  });

  test('updateQAC works  correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as QuestionsInspect).q_or_a.flag = 'q';

    (wrapper.instance() as QuestionsInspect).q_or_a.comment = {
      content: 'something else',
      question_id: 0,
      comment_id: 0,
      timestamp: '2',
      user_id: 0,
      username: '',
    };

    for (let i = 0; (wrapper.instance() as QuestionsInspect).input.content.length <= 500; i++) {
      (wrapper.instance() as QuestionsInspect).input.content += 'This is a long comment . ';
    }
    (wrapper.instance() as QuestionsInspect).updateQAC();

    expect(Alert.danger).toHaveBeenCalledWith(
      'Error updating: Comment cannot exceed 500 characters',
    );

    (wrapper.instance() as QuestionsInspect).q_or_a.flag = 'q';
    (wrapper.instance() as QuestionsInspect).q_or_a.question = {
      title: 'something',
      content: 'something else',
      question_id: 0,
      timestamp: '2',
      answered: true,
      user_id: 0,
      username: '',
      upvotes: 0,
      answers: [],
    };

    (wrapper.instance() as QuestionsInspect).input.content = '';

    (wrapper.instance() as QuestionsInspect).updateQAC();
    expect(Alert.danger).toHaveBeenLastCalledWith(
      'Error updating: Title and content cant be empty',
    );

    (wrapper.instance() as QuestionsInspect).input.title = 'test1';
    (wrapper.instance() as QuestionsInspect).input.content = 'test2';

    (wrapper.instance() as QuestionsInspect).updateQAC();

    expect(Alert.danger).toHaveBeenLastCalledWith(
      'Error updating: Title and content cant be empty',
    );
    // this.q_or_a.question.title = this.input.title;
    // this.q_or_a.question.content
    expect((wrapper.instance() as QuestionsInspect).q_or_a.question?.title).toBe('test1');
    expect((wrapper.instance() as QuestionsInspect).q_or_a.question?.content).toBe('test2');

    (wrapper.instance() as QuestionsInspect).q_or_a.question = null;
    (wrapper.instance() as QuestionsInspect).input.content = '';

    (wrapper.instance() as QuestionsInspect).updateQAC();

    expect(Alert.danger).toHaveBeenLastCalledWith('Error updating: Content cant be empty');

    (wrapper.instance() as QuestionsInspect).input.content = 'test3';
    (wrapper.instance() as QuestionsInspect).updateQAC();

    expect((wrapper.instance() as QuestionsInspect).q_or_a.comment?.content).toBe('test3');

    (wrapper.instance() as QuestionsInspect).input.content = '';

    (wrapper.instance() as QuestionsInspect).q_or_a.flag = 'a';

    (wrapper.instance() as QuestionsInspect).q_or_a.answer = {
      content: 'something else',
      question_id: 0,
      timestamp: '2',
      user_id: 0,
      username: '',
      upvotes: 0,
      answer_id: 2,
      best_answer: true,
      comments: [],
    };

    (wrapper.instance() as QuestionsInspect).updateQAC();
    //make sure its not reading the last instance
    expect(Alert.danger).toHaveBeenCalledTimes(4);
    expect(Alert.danger).toHaveBeenLastCalledWith('Error updating: Content cant be empty');

    (wrapper.instance() as QuestionsInspect).input.content = 'test4';
    (wrapper.instance() as QuestionsInspect).updateQAC();

    expect((wrapper.instance() as QuestionsInspect).q_or_a.answer?.content).toBe('test4');

    (wrapper.instance() as QuestionsInspect).input.content = '';

    (wrapper.instance() as QuestionsInspect).q_or_a.answer = null;

    (wrapper.instance() as QuestionsInspect).updateQAC();
    //make sure its not reading the last instance
    expect(Alert.danger).toHaveBeenCalledTimes(5);
    expect(Alert.danger).toHaveBeenLastCalledWith('Error updating: Content cant be empty');

    (wrapper.instance() as QuestionsInspect).input.content = 'test5';
    (wrapper.instance() as QuestionsInspect).updateQAC();

    expect((wrapper.instance() as QuestionsInspect).q_or_a.comment?.content).toBe('test5');

    (wrapper.instance() as QuestionsInspect).updateQAC();
    expect((wrapper.instance() as QuestionsInspect).input.update_toggle).toBe(false);
  });
});
