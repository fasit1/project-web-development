import * as React from 'react';
import { SideBar, TopBar } from '../src/components/barComponents';
import { shallow } from 'enzyme';
import { Button, Form } from '../src/components/widgets';

jest.mock('../src/services/tagServices', () => {
  class TagServices {
    getFavorites() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
      ]);
    }
    getPopular() {
      return Promise.resolve([
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
    getAll() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
  }
  return new TagServices();
});

jest.mock('../src/services/userServices', () => {
  class UserService {
    getUser() {
      return Promise.resolve({
        user_id: 1,
        username: 'user1',
        email: 'user@user.no',
        picture: 'url.com',
      });
    }

    authenticateUser() {
      return Promise.resolve(true);
    }

    getAllUsers() {
      return Promise.resolve([
        {
          user_id: 1,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 2,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 3,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
      ]);
    }
  }
  return new UserService();
});

jest.mock('../src/services/questionServices', () => {
  class QuestionsServices {
    getQuestion() {
      return Promise.resolve({
        question_id: 1,
        title: 'title1',
        content: 'content1',
        timestamp: new Date(1),
        answered: false,
        user_id: 1,
        username: 'user1',
        upvotes: 10,
        answers: [],
        tags: { content: 'tag1' },
        comments: [],
        voted_by_user: 0,
      });
    }

    getEveryQuestion() {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag1' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag2' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag3' },
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
  }

  return new QuestionsServices();
});

describe('SideBar tests', () => {
  test('Sidebar draws correctly after mount', async () => {
    const wrapper = shallow(<SideBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });

  test('Sidebar draws correctly after mount with popular toggle', async () => {
    const wrapper = shallow(<SideBar />);

    (wrapper.instance() as SideBar).popularToggle = true;

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });

  test('Sidebar draws correctly after mount with favorite toggle', async () => {
    const wrapper = shallow(<SideBar />);

    (wrapper.instance() as SideBar).favoriteToggle = true;

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });

  test('SideBar "tags" links correctly', async () => {
    const wrapper = shallow(<SideBar />);
    wrapper.find('h3').simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe('#/tags');
  });

  test('SideBar favorite 0 links correctly', async () => {
    const wrapper = shallow(<SideBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as SideBar).favoriteToggle = true;

    const p = wrapper.find('p').at(0);
    p.simulate('click');

    expect(location.hash).toBe(`#/tags/${(wrapper.instance() as SideBar).favorites[0].content}`);
  });

  test('SideBar popular 0 links correctly', async () => {
    const wrapper = shallow(<SideBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as SideBar).popularToggle = true;
    (wrapper.instance() as SideBar).favoriteToggle = false;

    const p = wrapper.find('p').at(0);
    p.simulate('click');

    expect(location.hash).toBe(`#/tags/${(wrapper.instance() as SideBar).popular[0].content}`);
  });

  test('SideBar favorites links correctly when not logged in', async () => {
    const wrapper = shallow(<SideBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as SideBar).userAuthenticated = false;
    (wrapper.instance() as SideBar).favoriteToggle = true;

    const p = wrapper.find('p').at(0);
    p.simulate('click');

    expect(location.hash).toBe(`#/login`);
  });

  test('toggles favoriteToggle and sets popularToggle to false on favorite click', () => {
    const wrapper = shallow(<SideBar />);

    const h5 = wrapper.find('h5').at(0);
    h5.simulate('click');

    expect((wrapper.instance() as SideBar).favoriteToggle).toBe(true);
    expect((wrapper.instance() as SideBar).popularToggle).toBe(false);

    h5.simulate('click');

    expect((wrapper.instance() as SideBar).favoriteToggle).toBe(false);
    expect((wrapper.instance() as SideBar).popularToggle).toBe(false);
  });

  test('toggles favoriteToggle and sets popularToggle to false on popular click', () => {
    const wrapper = shallow(<SideBar />);

    const h5 = wrapper.find('h5').at(1);
    h5.simulate('click');

    expect((wrapper.instance() as SideBar).favoriteToggle).toBe(false);
    expect((wrapper.instance() as SideBar).popularToggle).toBe(true);

    h5.simulate('click');

    expect((wrapper.instance() as SideBar).favoriteToggle).toBe(false);
    expect((wrapper.instance() as SideBar).popularToggle).toBe(false);
  });
});

describe('TopBar tests', () => {
  test('TopBar draws correctly after mount', async () => {
    const wrapper = shallow(<TopBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });

  test('TopBar profile img and createquestions links correctly', async () => {
    const wrapper = shallow(<TopBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const img = wrapper.find('img').at(0);
    img.simulate('click');
    expect(location.hash).toBe(`#/questions`);

    const createUser = wrapper.find('span').at(0);
    createUser.simulate('click');
    expect(location.hash).toBe(`#/questions/create`);

    const profile = wrapper.find('span').at(1);
    profile.simulate('click');
    expect(location.hash).toBe(`#/profile/${(wrapper.instance() as TopBar).user?.username}`);
  });

  test('TopBar create user and login links correctly', async () => {
    const wrapper = shallow(<TopBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    (wrapper.instance() as TopBar).user = null;
    const createUser = wrapper.find('span').at(1);
    createUser.simulate('click');
    expect(location.hash).toBe(`#/createUser`);
    const login = wrapper.find('span').at(2);
    login.simulate('click');
    expect(location.hash).toBe(`#/login`);
  });

  test('TopBar searchbar toggles on focus and on blur correctly', async () => {
    const wrapper = shallow(<TopBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const input = wrapper.find(Form.Input).at(0);
    input.simulate('focus');
    expect((wrapper.instance() as TopBar).search_toggle).toBe(true);
    input.simulate('blur');
    //wait for onblur timeout
    await new Promise((resolve) => setTimeout(resolve, 500));
    expect((wrapper.instance() as TopBar).search_toggle).toBe(false);
  });

  test('TopBar searchbar changes values correctly', async () => {
    const wrapper = shallow(<TopBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const input = wrapper.find(Form.Input).at(0);
    input.simulate('change', { currentTarget: { value: 'test' } });
    expect((wrapper.instance() as TopBar).search_value).toBe('test');
  });

  test('TopBar searchbar lists tags and links correctly', async () => {
    const wrapper = shallow(<TopBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const input = wrapper.find(Form.Input).at(0);
    input.simulate('change', { currentTarget: { value: '#' } });
    await new Promise((resolve) => setTimeout(resolve, 0));
    (wrapper.instance() as TopBar).search_toggle = true;
    expect(wrapper).toMatchSnapshot();

    const button = wrapper.find(Button.Success).at(0);
    button.simulate('click');

    expect(location.hash).toBe(`#/tags/${(wrapper.instance() as TopBar).all.tags[0].content}`);
  });
  test('TopBar searchbar lists users and links correctly', async () => {
    const wrapper = shallow(<TopBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const input = wrapper.find(Form.Input).at(0);
    input.simulate('change', { currentTarget: { value: '$' } });
    await new Promise((resolve) => setTimeout(resolve, 0));
    (wrapper.instance() as TopBar).search_toggle = true;
    expect(wrapper).toMatchSnapshot();

    const button = wrapper.find(Button.Success).at(0);
    button.simulate('click');

    expect(location.hash).toBe(`#/profile/${(wrapper.instance() as TopBar).all.users[0].username}`);
  });

  test('TopBar searchbar lists questions and links correctly', async () => {
    const wrapper = shallow(<TopBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const input = wrapper.find(Form.Input).at(0);
    input.simulate('change', { currentTarget: { value: 't' } });
    await new Promise((resolve) => setTimeout(resolve, 0));
    (wrapper.instance() as TopBar).search_toggle = true;
    expect(wrapper).toMatchSnapshot();

    const button = wrapper.find(Button.Success).at(0);
    button.simulate('click');

    expect(location.hash).toBe(
      `#/questions/${(wrapper.instance() as TopBar).all.questions[0].question_id}`,
    );
  });

  test('TopBar searchbar random buttons links correctly', async () => {
    const wrapper = shallow(<TopBar />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as TopBar).search_toggle = true;

    const rq = wrapper.find(Button.Light).at(0);

    rq.simulate('click');
    expect(location.hash).toContain(`#/questions/`);

    const rt = wrapper.find(Button.Light).at(1);
    rt.simulate('click');

    expect(location.hash).toContain(`#/tags/`);

    const ru = wrapper.find(Button.Light).at(2);
    ru.simulate('click');

    expect(location.hash).toContain(`#/profile/`);
  });
});
