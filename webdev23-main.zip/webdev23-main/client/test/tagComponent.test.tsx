import * as React from 'react';
import { shallow } from 'enzyme';
import { Form, Alert } from '../src/components/widgets';
import { Tag, TagWithAmount } from '../src/components/customTypes';
import { Tags } from '../src/components/tagComponent';

jest.spyOn(Alert, 'danger').mockImplementation((text) => {});
jest.spyOn(console, 'error').mockImplementation((text) => {});

jest.mock('../src/services/tagServices', () => {
  class TagServices {
    getFavorites() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
      ]);
    }
    getPopular() {
      return Promise.resolve([
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
    getAll() {
      return Promise.resolve<TagWithAmount[]>([
        { content: 'a-tag', question_amount: 1 },
        { content: 'b-tag', question_amount: 3 },
        { content: 'c-tag', question_amount: 2 },
      ]);
    }
  }
  return new TagServices();
});

jest.mock('../src/services/userServices', () => {
  class UserService {
    getUser() {
      return Promise.resolve({
        user_id: 1,
        username: 'user1',
        email: 'user@user.no',
        picture: 'url.com',
      });
    }

    authenticateUser() {
      return Promise.resolve(true);
    }

    getAllUsers() {
      return Promise.resolve([
        {
          user_id: 1,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 2,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 3,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
      ]);
    }
    create(username: string, password: string, email: string, firstName: string, lastName: string) {
      return Promise.resolve();
    }

    login(username: string, password: string) {
      return Promise.resolve();
    }
  }

  return new UserService();
});

jest.mock('../src/services/questionServices', () => {
  class QuestionsServices {
    getQuestion() {
      return Promise.resolve({
        question_id: 1,
        title: 'title1',
        content: 'content1',
        timestamp: new Date(1),
        answered: false,
        user_id: 1,
        username: 'user1',
        upvotes: 10,
        answers: [],
        tags: { content: 'tag1' },
        comments: [],
        voted_by_user: 0,
      });
    }

    getEveryQuestion() {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag1' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag2' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag3' },
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    createQuestion(title: string, content: string, tags: Tag[]) {
      return Promise.resolve();
    }
  }

  return new QuestionsServices();
});

describe('TagComponent tests', () => {
  afterEach(() => {
    jest.spyOn(Alert, 'danger').mockClear();
    jest.spyOn(console, 'error').mockClear();
  });

  test('Tag page draws correctly after mount', async () => {
    const wrapper = shallow(<Tags />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });
  test('Tag page select changes sortMethod correctly', async () => {
    const wrapper = shallow(<Tags />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const select = wrapper.find(Form.Select).at(0);
    select.simulate('change', { target: { value: 'alphabetical' } });

    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as Tags).sortMethod).toBe('alphabetical');
  });

  test('Tag page input changes tag_search_input and calls sortTags() correctly', async () => {
    const wrapper = shallow(<Tags />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const input = wrapper.find(Form.Input).at(0);
    input.simulate('change', { currentTarget: { value: '#a Tag$' } });

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as Tags).tag_search_input).toBe('a-tag');
    expect((wrapper.instance() as Tags).filteredTags).toStrictEqual([
      { content: 'a-tag', question_amount: 1 },
    ]);
  });

  test('Tag links correctly to tag-page onClick()', async () => {
    location.hash = '#/tags';

    const wrapper = shallow(<Tags />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const input = wrapper.find('div').at(1);
    input.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));
    //b-tag since standard sorting is htl.
    expect(location.hash).toBe('#/tags/b-tag');
  });

  test('hoveredCard changes correctly on tag onMouseEnter and onMouseLeave ', async () => {
    const wrapper = shallow(<Tags />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const input = wrapper.find('div').at(1);
    input.simulate('mouseEnter');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as Tags).hoveredCard).toBe(0);

    input.simulate('mouseLeave');

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as Tags).hoveredCard).toBe(-1);
  });

  test('sortTags() sorts tags correctly', async () => {
    const wrapper = shallow(<Tags />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as Tags).sortMethod = 'alphabetical';
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as Tags).sortTags();
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as Tags).filteredTags).toStrictEqual([
      { content: 'a-tag', question_amount: 1 },
      { content: 'b-tag', question_amount: 3 },
      { content: 'c-tag', question_amount: 2 },
    ]);

    (wrapper.instance() as Tags).sortMethod = 'htl';
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as Tags).sortTags();
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as Tags).filteredTags).toStrictEqual([
      { content: 'b-tag', question_amount: 3 },
      { content: 'c-tag', question_amount: 2 },
      { content: 'a-tag', question_amount: 1 },
    ]);

    (wrapper.instance() as Tags).sortMethod = 'lth';
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as Tags).sortTags();
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect((wrapper.instance() as Tags).filteredTags).toStrictEqual([
      { content: 'a-tag', question_amount: 1 },
      { content: 'c-tag', question_amount: 2 },
      { content: 'b-tag', question_amount: 3 },
    ]);
  });
});
