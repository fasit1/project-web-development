import * as React from 'react';
import { shallow } from 'enzyme';
import { Alert } from '../src/components/widgets';
import { Answer, Question, Tag } from '../src/components/customTypes';
import { LoginPage } from '../src/components/loginComponent';
import userService from '../src/services/userServices';
import { AxiosError } from 'axios';
import { QuestionsInspect } from '../src/components/questionInspectComponent';
import questionServices from '../src/services/questionServices';
import answerServices from '../src/services/answerServices';

jest.mock('../src/services/tagServices', () => {
  class TagServices {
    getFavorites() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
      ]);
    }
    getPopular() {
      return Promise.resolve([
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
    getAll() {
      return Promise.resolve([
        { content: 'a-tag', question_amount: 1 },
        { content: 'b-tag', question_amount: 3 },
        { content: 'c-tag', question_amount: 2 },
      ]);
    }

    removeFromFavorites() {
      return Promise.resolve();
    }

    addToFavorites() {
      return Promise.resolve();
    }
  }
  return new TagServices();
});

jest.mock('../src/services/userServices', () => {
  class UserService {
    getUser() {
      return Promise.resolve({
        user_id: 1,
        username: 'user1',
        email: 'user@user.no',
        picture: 'url.com',
      });
    }

    authenticateUser() {
      return Promise.resolve(true);
    }

    getAllUsers() {
      return Promise.resolve([
        {
          user_id: 1,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 2,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 3,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
      ]);
    }
    create(username: string, password: string, email: string, firstName: string, lastName: string) {
      return Promise.resolve();
    }

    login(username: string, password: string) {
      return Promise.resolve();
    }
  }

  return new UserService();
});

jest.mock('../src/services/questionServices', () => {
  class QuestionsServices {
    getQuestion() {
      return Promise.resolve({
        question_id: 1,
        title: 'title1',
        content: 'content1',
        timestamp: new Date(1),
        answered: false,
        user_id: 1,
        username: 'user1',
        upvotes: 10,
        answers: [
          {
            answer_id: 26,
            best_answer: true,
            comments: [
              {
                answer_id: 26,
                comment_id: 15,
                content: 'a',
                fullname: 'test test',
                timestamp: '2023-11-19T11:41:46.000Z',
                user_id: 1,
                username: 'user1',
              },
            ],
            content: 'a',
            fullname: 'test test',
            question_id: 27,
            timestamp: '2023-11-18T15:55:21.000Z',
            upvotes: 0,
            user_id: 1,
            username: 'user1',
            voted_by_user: 2,
          },
        ],
        tags: [{ content: 'tag1' }],
        comments: [
          {
            comment_id: 11,
            content: 'halla',
            fullname: 'test test',
            question_id: 27,
            timestamp: '2023-11-19T11:41:42.000Z',
            user_id: 1,
            username: 'user1',
          },
        ],
        voted_by_user: 0,
      });
    }

    deleteQuestion(question_id: number) {
      return Promise.resolve();
    }

    deleteComment(comment_id: number) {
      return Promise.resolve();
    }
    upvote(question_id: number) {
      return Promise.resolve();
    }

    downvote(question_id: number) {
      return Promise.resolve();
    }
    update(qustion: Question) {
      return Promise.resolve();
    }

    editComment(comment: Comment) {
      return Promise.resolve();
    }

    getAllQuestions(questionsType: string, answered: boolean | undefined) {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: ['tag1'],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: ['tag2'],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: ['tag3'],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    getEveryQuestion() {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag1' }],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag2' }],
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag3' }],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }

    selectBestAnswer(answer: Answer) {
      return Promise.resolve();
    }

    unselectBestAnswer(answer: Answer) {
      return Promise.resolve();
    }
    createQuestion(title: string, content: string, tags: Tag[]) {
      return Promise.resolve();
    }

    saveQuestion(questions: Question) {
      return Promise.resolve();
    }

    unsaveQuestion(questions: Question) {
      return Promise.resolve();
    }
    getSavedQuestions() {
      return Promise.resolve([
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: [{ content: 'tag3' }],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    getQuestionsByTag(tag: string, questionsType: string, answered: boolean | undefined) {
      return Promise.resolve([
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: ['tag3'],
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
  }

  return new QuestionsServices();
});

jest.mock('../src/services/answerServices', () => {
  class AnswerServcie {
    upvote(question_id: number) {
      return Promise.resolve();
    }

    downvote(question_id: number) {
      return Promise.resolve();
    }

    update(answer: Answer) {
      return Promise.resolve();
    }

    deleteAnswer(answer_id: number) {
      return Promise.resolve();
    }

    deleteComment(comment_id: number) {
      return Promise.resolve();
    }

    editComment(comment_id: number) {
      return Promise.resolve();
    }
  }

  return new AnswerServcie();
});

jest.spyOn(Alert, 'danger').mockImplementation((text) => {});
jest.spyOn(console, 'error').mockImplementation((text) => {});

describe('LoginComponent fail tests', () => {
  test('loginButton catch works correctyl', async () => {
    const wrapper = shallow(<LoginPage />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    userService.login = jest.fn(() => Promise.reject(new Error('some error')));

    (wrapper.instance() as LoginPage).loginButton();
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(Alert.danger).toHaveBeenLastCalledWith('Error logging in: Unkown error');

    userService.login = jest.fn(() =>
      Promise.reject(
        new AxiosError('some error', undefined, undefined, undefined, {
          data: { message: 'Error message from Axios' },
          status: 401,
          statusText: 'Unauthorized',
          headers: {},
          //@ts-ignore
          config: {},
        }),
      ),
    );

    (wrapper.instance() as LoginPage).loginButton();
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(Alert.danger).toHaveBeenLastCalledWith('Error logging in: Error message from Axios');
  });
});

describe('QuestionComponent fail tests', () => {
  test('upvoteQuestionButton fails correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    questionServices.upvote = jest.fn(() => Promise.reject(new Error('some error 1')));
    (wrapper.instance() as QuestionsInspect).upvoteQuestionButton(2);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(console.error).toHaveBeenLastCalledWith(new Error('some error 1'));
  });
});

describe('QuestionInspect fail tests', () => {
  test('upvoteQuestionButton fails correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    questionServices.upvote = jest.fn(() => Promise.reject(new Error('some error 1')));
    (wrapper.instance() as QuestionsInspect).upvoteQuestionButton(2);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(console.error).toHaveBeenLastCalledWith(new Error('some error 1'));
  });

  test('removePinAnswerButton fails correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    questionServices.unselectBestAnswer = jest.fn(() => Promise.reject(new Error('some error 2')));

    (wrapper.instance() as QuestionsInspect).removePinAnswerButton({
      answer_id: 26,
      best_answer: true,
      comments: [],
      content: 'a',
      question_id: 27,
      timestamp: '2023-11-18T15:55:21.000Z',
      upvotes: 0,
      user_id: 1,
      username: 'user1',
      voted_by_user: 2,
    });

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(console.error).toHaveBeenLastCalledWith(new Error('some error 2'));
  });

  test('downvoteQuestionButton fails correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    questionServices.downvote = jest.fn(() => Promise.reject(new Error('some error 3')));

    (wrapper.instance() as QuestionsInspect).downvoteQuestionButton(1);

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(console.error).toHaveBeenLastCalledWith(new Error('some error 3'));
  });

  test('upvoteAnswerButton fails correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    answerServices.upvote = jest.fn(() => Promise.reject(new Error('some error 4')));

    (wrapper.instance() as QuestionsInspect).upvoteAnswerButton(1);

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(console.error).toHaveBeenLastCalledWith(new Error('some error 4'));
  });

  test('downvoteAnswerButton fails correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    answerServices.downvote = jest.fn(() => Promise.reject(new Error('some error 5')));

    (wrapper.instance() as QuestionsInspect).downvoteAnswerButton(1);

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(console.error).toHaveBeenLastCalledWith(new Error('some error 5'));
  });

  test('deleteQComment fails correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    questionServices.deleteComment = jest.fn(() => Promise.reject(new Error('some error 6')));

    (wrapper.instance() as QuestionsInspect).deleteQComment({
      comment_id: 0,
      content: '',
      timestamp: '',
      user_id: 1,
      username: '',
      question_id: 1,
    });

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(console.error).toHaveBeenLastCalledWith(new Error('some error 6'));
  });

  test('deleteAComment fails correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    answerServices.deleteComment = jest.fn(() => Promise.reject(new Error('some error 7')));

    (wrapper.instance() as QuestionsInspect).deleteAComment({
      comment_id: 0,
      content: '',
      timestamp: '',
      user_id: 1,
      username: '',
      answer_id: 1,
    });

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(console.error).toHaveBeenLastCalledWith(new Error('some error 7'));
  });

  test('deletePost fails correctly', async () => {
    const wrapper = shallow(<QuestionsInspect match={{ params: { id: '1' } }} />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    questionServices.deleteQuestion = jest.fn(() => Promise.reject(new Error('some error 8')));
    answerServices.deleteAnswer = jest.fn(() => Promise.reject(new Error('some error 8.5')));

    (wrapper.instance() as QuestionsInspect).deletePost('q', 1);

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(console.error).toHaveBeenLastCalledWith(new Error('some error 8'));

    (wrapper.instance() as QuestionsInspect).deletePost('a', 1);

    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(console.error).toHaveBeenLastCalledWith(new Error('some error 8.5'));
  });
});
