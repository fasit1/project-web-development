import * as React from 'react';
import { shallow } from 'enzyme';
import { CreateQuestion } from '../src/components/createQuestionComponent';
import { Button, Form, Alert } from '../src/components/widgets';
import { Tag } from 'src/components/customTypes';

jest.spyOn(Alert, 'danger').mockImplementation((text) => {});
jest.spyOn(console, 'error').mockImplementation((text) => {});

jest.mock('../src/services/tagServices', () => {
  class TagServices {
    getFavorites() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
      ]);
    }
    getPopular() {
      return Promise.resolve([
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
    getAll() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
  }
  return new TagServices();
});

jest.mock('../src/services/userServices', () => {
  class UserService {
    getUser() {
      return Promise.resolve({
        user_id: 1,
        username: 'user1',
        email: 'user@user.no',
        picture: 'url.com',
      });
    }

    authenticateUser() {
      return Promise.resolve(true);
    }

    getAllUsers() {
      return Promise.resolve([
        {
          user_id: 1,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 2,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 3,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
      ]);
    }
  }
  return new UserService();
});

jest.mock('../src/services/questionServices', () => {
  class QuestionsServices {
    getQuestion() {
      return Promise.resolve({
        question_id: 1,
        title: 'title1',
        content: 'content1',
        timestamp: new Date(1),
        answered: false,
        user_id: 1,
        username: 'user1',
        upvotes: 10,
        answers: [],
        tags: { content: 'tag1' },
        comments: [],
        voted_by_user: 0,
      });
    }

    getEveryQuestion() {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag1' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag2' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag3' },
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    createQuestion(title: string, content: string, tags: Tag[]) {
      return Promise.resolve();
    }
  }

  return new QuestionsServices();
});

describe('CreateQuestion tests', () => {
  afterEach(() => {
    jest.spyOn(Alert, 'danger').mockClear();
    jest.spyOn(console, 'error').mockClear();
  });
  test('CreateQuestion draws correctly after mount', async () => {
    const wrapper = shallow(<CreateQuestion />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });

  test('CreateQuestion inputs/textareas changes values correctly', async () => {
    const wrapper = shallow(<CreateQuestion />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const title = wrapper.find(Form.Input).at(0);
    title.simulate('change', { currentTarget: { value: 'test' } });
    expect((wrapper.instance() as CreateQuestion).input.title).toBe('test');

    const content = wrapper.find(Form.Textarea).at(0);
    content.simulate('change', { currentTarget: { value: 'test' } });
    expect((wrapper.instance() as CreateQuestion).input.content).toBe('test');

    const tags = wrapper.find(Form.Input).at(1);
    tags.simulate('change', { currentTarget: { value: 'Test123' } });
    expect((wrapper.instance() as CreateQuestion).input.title).toBe('test');
  });

  test('CreateQuestion onfocus works correctly', async () => {
    const wrapper = shallow(<CreateQuestion />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const tags = wrapper.find(Form.Input).at(1);
    tags.simulate('focus');
    expect((wrapper.instance() as CreateQuestion).search_toggle).toBe(true);
  });

  test('Add tag buttons works correctly with input.tags empty', async () => {
    const wrapper = shallow(<CreateQuestion />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as CreateQuestion).search_toggle = true;
    const tags = wrapper.find(Form.Input).at(1);
    tags.simulate('change', { currentTarget: { value: 'f' } });
    const button = wrapper.find(Button.Success).at(0);
    button.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as CreateQuestion).input.tags).toEqual([
      (wrapper.instance() as CreateQuestion).tags[0],
    ]);
  });
  test('Add tag buttons works correctly with input.tags full', async () => {
    const wrapper = shallow(<CreateQuestion />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as CreateQuestion).search_toggle = true;

    (wrapper.instance() as CreateQuestion).input.tags = [
      { content: 'tag1' },
      { content: 'tag2' },
      { content: 'tag3' },
      { content: 'tag4' },
      { content: 'tag5' },
    ];

    const tags = wrapper.find(Form.Input).at(1);
    tags.simulate('change', { currentTarget: { value: 'f' } });
    const button = wrapper.find(Button.Success).at(0);
    button.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(Alert.danger).toHaveBeenCalledWith('Max amount of tags are 5');
  });

  test('create tag button works correctly with input.tags empty', async () => {
    const wrapper = shallow(<CreateQuestion />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as CreateQuestion).search_toggle = true;
    const tags = wrapper.find(Form.Input).at(1);
    tags.simulate('change', { currentTarget: { value: 'x' } });
    const button = wrapper.find(Button.Success).at(0);
    button.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as CreateQuestion).input.tags).toEqual([{ content: 'x' }]);
  });

  test('Selected tags are deleted on click', async () => {
    const wrapper = shallow(<CreateQuestion />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    (wrapper.instance() as CreateQuestion).search_toggle = true;

    (wrapper.instance() as CreateQuestion).input.tags = [
      { content: 'tag1' },
      { content: 'tag2' },
      { content: 'tag3' },
      { content: 'tag4' },
      { content: 'tag5' },
    ];

    const span = wrapper.find('span').at(1);
    span.simulate('click');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect((wrapper.instance() as CreateQuestion).input.tags).toEqual([
      { content: 'tag2' },
      { content: 'tag3' },
      { content: 'tag4' },
      { content: 'tag5' },
    ]);
  });

  test('Cancel button sets path correctly', async () => {
    const wrapper = shallow(<CreateQuestion />);
    location.hash = '#/questions/create';
    await new Promise((resolve) => setTimeout(resolve, 0));
    const button = wrapper.find(Button.Danger).at(0);
    button.simulate('click');
    expect(location.hash).toBe(`#/questions`);
  });

  test('Post button handels invalid input correctly', async () => {
    location.hash = '#/questions/create';

    const wrapper = shallow(<CreateQuestion />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    (wrapper.instance() as CreateQuestion).postButton();
    expect(Alert.danger).toHaveBeenCalledWith(`Error creating question: A question needs a title`);
    expect(Alert.danger).toHaveBeenCalledWith(`Error creating question: A question needs a title`);

    for (let i = 0; (wrapper.instance() as CreateQuestion).input.title.length <= 300; i++) {
      (wrapper.instance() as CreateQuestion).input.title += 'This is a long title . ';
    }
    (wrapper.instance() as CreateQuestion).postButton();
    expect(Alert.danger).toHaveBeenCalledWith(
      `Error creating question: Title cannot be more than 255 characters`,
    );
    expect(Alert.danger).toHaveBeenCalledWith(
      `Error creating question: Title cannot be more than 255 characters`,
    );
    (wrapper.instance() as CreateQuestion).input.title = 'test';
    (wrapper.instance() as CreateQuestion).postButton();
    expect(Alert.danger).toHaveBeenCalledWith(`Error creating question: A question needs content`);
    expect(Alert.danger).toHaveBeenCalledWith(`Error creating question: A question needs content`);

    (wrapper.instance() as CreateQuestion).input.content = 'testtest';
    (wrapper.instance() as CreateQuestion).postButton();
    expect(Alert.danger).toHaveBeenCalledWith(
      `Error creating question: A question needs at least one Tag`,
    );
    expect(Alert.danger).toHaveBeenCalledWith(
      `Error creating question: A question needs at least one Tag`,
    );

    (wrapper.instance() as CreateQuestion).input.title = 'test';
    (wrapper.instance() as CreateQuestion).input.content = 'testtest';
    (wrapper.instance() as CreateQuestion).input.tags.push({ content: 'testtest' });
    (wrapper.instance() as CreateQuestion).postButton();

    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe(`#/questions`);
  });
});
