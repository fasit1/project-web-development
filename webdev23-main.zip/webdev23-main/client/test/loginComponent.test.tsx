import * as React from 'react';
import { shallow } from 'enzyme';
import { Button, Form, Alert } from '../src/components/widgets';
import { Tag } from '../src/components/customTypes';
import { LoginPage } from '../src/components/loginComponent';

jest.spyOn(Alert, 'danger').mockImplementation((text) => {});
jest.spyOn(console, 'error').mockImplementation((text) => {});

jest.mock('../src/services/tagServices', () => {
  class TagServices {
    getFavorites() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
      ]);
    }
    getPopular() {
      return Promise.resolve([
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
    getAll() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
  }
  return new TagServices();
});

jest.mock('../src/services/userServices', () => {
  class UserService {
    getUser() {
      return Promise.resolve({
        user_id: 1,
        username: 'user1',
        email: 'user@user.no',
        picture: 'url.com',
      });
    }

    authenticateUser() {
      return Promise.resolve(true);
    }

    getAllUsers() {
      return Promise.resolve([
        {
          user_id: 1,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 2,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 3,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
      ]);
    }
    create(username: string, password: string, email: string, firstName: string, lastName: string) {
      return Promise.resolve();
    }

    login(username: string, password: string) {
      return Promise.resolve();
    }
  }

  return new UserService();
});

jest.mock('../src/services/questionServices', () => {
  class QuestionsServices {
    getQuestion() {
      return Promise.resolve({
        question_id: 1,
        title: 'title1',
        content: 'content1',
        timestamp: new Date(1),
        answered: false,
        user_id: 1,
        username: 'user1',
        upvotes: 10,
        answers: [],
        tags: { content: 'tag1' },
        comments: [],
        voted_by_user: 0,
      });
    }

    getEveryQuestion() {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag1' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag2' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag3' },
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    createQuestion(title: string, content: string, tags: Tag[]) {
      return Promise.resolve();
    }
  }

  return new QuestionsServices();
});

describe('Login tests', () => {
  afterEach(() => {
    jest.spyOn(Alert, 'danger').mockClear();
    jest.spyOn(console, 'error').mockClear();
  });

  test('LoginPage draws correctly after mount', async () => {
    const wrapper = shallow(<LoginPage />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });

  test('CrateUser inputs changes values correctly', async () => {
    location.hash = '#/login';
    const wrapper = shallow(<LoginPage />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const username = wrapper.find(Form.Input).at(0);
    username.simulate('change', { currentTarget: { value: 'username' } });
    expect((wrapper.instance() as LoginPage).username).toBe('username');

    const password = wrapper.find(Form.Input).at(1);
    password.simulate('change', { currentTarget: { value: 'password' } });
    expect((wrapper.instance() as LoginPage).password).toBe('password');
  });

  test('CrateUser password input calls loginButton() on "enter", and links correctly', async () => {
    const wrapper = shallow(<LoginPage />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/login';

    const password = wrapper.find(Form.Input).at(1);
    password.simulate('keyDown', { key: 'Enter' });

    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe('#/questions');
  });

  test('login button calls loginButton() onClick, and links correctly', async () => {
    const wrapper = shallow(<LoginPage />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/login';

    const button = wrapper.find(Button.Success).at(0);
    button.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe('#/questions');
  });

  test('CrateUser.registrationButton() links correctly on success', async () => {
    const wrapper = shallow(<LoginPage />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/login';

    const u = wrapper.find('u').at(0);
    u.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe('#/createUser');
  });
});
