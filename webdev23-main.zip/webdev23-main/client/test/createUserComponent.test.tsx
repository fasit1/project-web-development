import * as React from 'react';
import { shallow } from 'enzyme';
import { Button, Form, Alert } from '../src/components/widgets';
import { Tag } from 'src/components/customTypes';
import { CreateUser } from '../src/components/createUserComponent';

jest.spyOn(Alert, 'danger').mockImplementation((text) => {});
jest.spyOn(console, 'error').mockImplementation((text) => {});

jest.mock('../src/services/tagServices', () => {
  class TagServices {
    getFavorites() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
      ]);
    }
    getPopular() {
      return Promise.resolve([
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
    getAll() {
      return Promise.resolve([
        { content: 'favtag1' },
        { content: 'favtag2' },
        { content: 'favtag3' },
        { content: 'favtag4' },
        { content: 'poptag1' },
        { content: 'poptag2' },
        { content: 'poptag3' },
        { content: 'poptag4' },
      ]);
    }
  }
  return new TagServices();
});

jest.mock('../src/services/userServices', () => {
  class UserService {
    getUser() {
      return Promise.resolve({
        user_id: 1,
        username: 'user1',
        email: 'user@user.no',
        picture: 'url.com',
      });
    }

    authenticateUser() {
      return Promise.resolve(true);
    }

    getAllUsers() {
      return Promise.resolve([
        {
          user_id: 1,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 2,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
        {
          user_id: 3,
          username: 'user1',
          email: 'user@user.no',
          picture: 'url.com',
        },
      ]);
    }
    create(username: string, password: string, email: string, firstName: string, lastName: string) {
      return Promise.resolve();
    }

    login(username: string, password: string) {
      return Promise.resolve();
    }
  }

  return new UserService();
});

jest.mock('../src/services/questionServices', () => {
  class QuestionsServices {
    getQuestion() {
      return Promise.resolve({
        question_id: 1,
        title: 'title1',
        content: 'content1',
        timestamp: new Date(1),
        answered: false,
        user_id: 1,
        username: 'user1',
        upvotes: 10,
        answers: [],
        tags: { content: 'tag1' },
        comments: [],
        voted_by_user: 0,
      });
    }

    getEveryQuestion() {
      return Promise.resolve([
        {
          question_id: 1,
          title: 'title1',
          content: 'content1',
          timestamp: new Date(1),
          answered: false,
          user_id: 1,
          username: 'user1',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag1' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 2,
          title: 'title2',
          content: 'content2',
          timestamp: new Date(2),
          answered: false,
          user_id: 2,
          username: 'user2',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag2' },
          comments: [],
          voted_by_user: 0,
        },
        {
          question_id: 3,
          title: 'title3',
          content: 'content3',
          timestamp: new Date(3),
          answered: false,
          user_id: 3,
          username: 'user3',
          upvotes: 10,
          answers: [],
          tags: { content: 'tag3' },
          comments: [],
          voted_by_user: 0,
        },
      ]);
    }
    createQuestion(title: string, content: string, tags: Tag[]) {
      return Promise.resolve();
    }
  }

  return new QuestionsServices();
});

describe('CreateUser tests', () => {
  afterEach(() => {
    jest.spyOn(Alert, 'danger').mockClear();
    jest.spyOn(console, 'error').mockClear();
  });
  test('CrateUser draws correctly after mount', async () => {
    const wrapper = shallow(<CreateUser />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(wrapper).toMatchSnapshot();
  });
  test('CrateUser inputs changes values correctly', async () => {
    const wrapper = shallow(<CreateUser />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const username = wrapper.find(Form.Input).at(0);
    username.simulate('change', { currentTarget: { value: 'test#" $' } });
    expect((wrapper.instance() as CreateUser).username).toBe('test');

    const firstName = wrapper.find(Form.Input).at(1);
    firstName.simulate('change', { currentTarget: { value: 'first' } });
    expect((wrapper.instance() as CreateUser).firstName).toBe('first');

    const lastName = wrapper.find(Form.Input).at(2);
    lastName.simulate('change', { currentTarget: { value: 'last' } });
    expect((wrapper.instance() as CreateUser).lastName).toBe('last');

    const email = wrapper.find(Form.Input).at(3);
    email.simulate('change', { currentTarget: { value: 'email' } });
    expect((wrapper.instance() as CreateUser).email).toBe('email');

    const password = wrapper.find(Form.Input).at(4);
    password.simulate('change', { currentTarget: { value: 'psw' } });
    expect((wrapper.instance() as CreateUser).password).toBe('psw');

    const confirmPassword = wrapper.find(Form.Input).at(5);
    confirmPassword.simulate('change', { currentTarget: { value: 'psw' } });
    expect((wrapper.instance() as CreateUser).confirmPassword).toBe('psw');
  });

  test('CrateUser.registrationButton() works correctly', async () => {
    const wrapper = shallow(<CreateUser />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const password = wrapper.find(Form.Input).at(4);
    password.simulate('change', { currentTarget: { value: 'password' } });

    const confirmPassword = wrapper.find(Form.Input).at(5);
    confirmPassword.simulate('change', { currentTarget: { value: 'somethingelse' } });
    (wrapper.instance() as CreateUser).registrationButton();

    expect(Alert.danger).toHaveBeenCalledWith(
      'Password and password confirmation are not the same',
    );

    password.simulate('change', { currentTarget: { value: 'password' } });
    confirmPassword.simulate('change', { currentTarget: { value: 'password' } });
    const username = wrapper.find(Form.Input).at(0);
    username.simulate('change', { currentTarget: { value: 't' } });
    (wrapper.instance() as CreateUser).registrationButton();

    expect(Alert.danger).toHaveBeenCalledWith('Username too short. Min 2 characters');

    username.simulate('change', {
      currentTarget: { value: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa' },
    });
    (wrapper.instance() as CreateUser).registrationButton();
    expect(Alert.danger).toHaveBeenCalledWith('Username too long. Max 32 characters');

    username.simulate('change', {
      currentTarget: { value: 'test' },
    });
    password.simulate('change', { currentTarget: { value: '' } });
    confirmPassword.simulate('change', { currentTarget: { value: '' } });
    (wrapper.instance() as CreateUser).registrationButton();

    expect(Alert.danger).toHaveBeenCalledWith('Please fill out every field');
  });

  test('CrateUser.registrationButton() links correctly on success', async () => {
    const wrapper = shallow(<CreateUser />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/createUser';

    const username = wrapper.find(Form.Input).at(0);
    username.simulate('change', { currentTarget: { value: 'test#" $' } });

    const firstName = wrapper.find(Form.Input).at(1);
    firstName.simulate('change', { currentTarget: { value: 'first' } });

    const lastName = wrapper.find(Form.Input).at(2);
    lastName.simulate('change', { currentTarget: { value: 'last' } });

    const email = wrapper.find(Form.Input).at(3);
    email.simulate('change', { currentTarget: { value: 'email' } });

    const password = wrapper.find(Form.Input).at(4);
    password.simulate('change', { currentTarget: { value: 'psw' } });

    const confirmPassword = wrapper.find(Form.Input).at(5);
    confirmPassword.simulate('change', { currentTarget: { value: 'psw' } });

    (wrapper.instance() as CreateUser).registrationButton();
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe('#/questions');
  });

  test('CrateUser.registrationButton() links correctly on success', async () => {
    const wrapper = shallow(<CreateUser />);
    await new Promise((resolve) => setTimeout(resolve, 0));
    location.hash = '#/createUser';

    const u = wrapper.find('u').at(0);
    u.simulate('click');

    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(location.hash).toBe('#/login');
  });

  test('CrateUser register button calls registrationButton on click', async () => {
    const wrapper = shallow(<CreateUser />);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const button = wrapper.find(Button.Success).at(0);
    button.simulate('click');
    expect(Alert.danger).toHaveBeenCalledWith('Username too short. Min 2 characters');
  });
});
