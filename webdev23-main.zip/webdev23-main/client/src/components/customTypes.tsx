export type Question = {
  question_id: number;
  title: string;
  content: string;
  timestamp: string;
  answered: boolean;
  user_id: number;
  username: string;
  upvotes: number;
  answers: Answer[];
  tags?: Tag[];
  comments?: Q_comment[];
  voted_by_user?: number;
  //0 = has downvoted
  //1 = has upvoted
  //2 = has not voted
};

export type Answer = {
  answer_id: number;
  content: string;
  timestamp: string;
  best_answer: boolean;
  user_id: number;
  username: string;
  question_id: number;
  upvotes: number;
  comments: A_comment[];
  voted_by_user?: number;
  //0 = has downvoted
  //1 = has upvoted
  //2 = has not voted
};

export type Answer_title = {
  answer_id: number;
  content: string;
  timestamp: string;
  best_answer: boolean;
  user_id: number;
  username: string;
  question_id: number;
  upvotes: number;
  comments: A_comment[];
  title: string;
  voted_by_user?: number;
  //0 = has downvoted
  //1 = has upvoted
  //2 = has not voted
};

export type Q_comment = {
  comment_id: number;
  content: string;
  timestamp: string;
  user_id: number;
  question_id: number;
  username: string;
};
export type Q_comment_title = {
  comment_id: number;
  content: string;
  timestamp: string;
  user_id: number;
  question_id: number;
  username: string;
  title: string;
};

export type A_comment = {
  username: string;
  comment_id: number;
  content: string;
  timestamp: string;
  user_id: number;
  answer_id: number;
};

export type A_comment_title = {
  username: string;
  comment_id: number;
  question_id: number;
  content: string;
  timestamp: string;
  user_id: number;
  answer_id: number;
  title: string;
};

export type Tag = {
  content: string;
};
export type TagWithAmount = {
  content: string;
  question_amount: number;
};

export type User = {
  user_id: number;
  google_id?: number;
  username: string;
  fullname?: string;
  email: string;
  picture: string;
  about_me?: string;
};

export type UserWithPassword = {
  user_id: number;
  google_id?: number;
  username: string;
  fullname?: string;
  password: string;
  email: string;
  picture: string;
  about_me?: string;
};

export type Stats = {
  answers: number;
  questions: number;
  comments: number;
  points: number;
  xp: number;
  title: string;
};

export type contentType = {
  questions: Question[];
  answers: Answer_title[];
  q_comments: Q_comment_title[];
  a_comments: A_comment_title[];
  stats: Stats;
};

export type InputType = {
  title: string;
  content: string;
  tags: Tag[];
};

export type Q_or_A_Type = {
  flag: string;
  id: number;
  answer: null | Answer;
  question: null | Question;
  comment: null | A_comment | Q_comment;
};
