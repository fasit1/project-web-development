// @flow

/**
 * Configuration file for webpack.
 *
 * Webpack bundles several JavaScript files into a single file
 * for easier script embedding in an index.html file.
 */

const webpack = require('webpack');
const os = require('os');
const path = require('path');

const getLocalIpAddress = () => {
  const interfaces = os.networkInterfaces();
  for (const interfaceName in interfaces) {
    const interfaceInfo = interfaces[interfaceName];
    for (const info of interfaceInfo) {
      if (info.family === 'IPv4' && !info.internal) {
        return info.address;
      }
    }
  }
  return;
};

const environment = process.argv.includes('production') ? 'production' : 'development';
const isHTTPS = process.argv.includes('https');
const isDocker = process.env.NODE_ENV == 'docker' ? true : false;

let BASE_URL = {
  production: JSON.stringify(getLocalIpAddress()),
  development: JSON.stringify('localhost'),
};

if (process.env.NODE_ENV == 'docker') {
  console.log(process.env.NODE_ENV);
  // Set your ip-address here if build a Docker image
  const dockerIp = 'your_host_ip';
  BASE_URL.production = JSON.stringify(dockerIp);
}

let PORT_NUMBER = {
  production: isHTTPS ? JSON.stringify('443') : JSON.stringify('80'),
  development: JSON.stringify('3000'),
};

console.log(
  'IP-adr for access:',
  BASE_URL[environment],
  'on port:',
  PORT_NUMBER[environment],
  isHTTPS ? 'over https' : 'over http',
);

module.exports = (env) => {
  return {
    plugins: [
      new webpack.DefinePlugin({
        BASE_URL: BASE_URL[environment],
        PORT_NUMBER: PORT_NUMBER[environment],
        IS_HTTPS: isHTTPS,
        DOCKER: isDocker,
      }),
    ],
    entry: './src/index.tsx', // Initial file to bundle
    resolve: {
      extensions: ['.js', '.jsx', '.ts', '.tsx'],
    },
    output: {
      // Output file: ./public/bundle.js
      path: path.resolve(__dirname, 'public'),
      filename: 'bundle.js',
    },
    // Makes original source code available to the browser for easier identification of error causes.
    devtool: 'source-map',
    module: {
      rules: [
        {
          // Use babel to parse .tsx files in the src folder
          test: /\.tsx$/,
          include: path.resolve(__dirname, 'src'),
          use: ['babel-loader'],
        },
      ],
    },
  };
};
